package com.example.ui.components

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.installer.AdminApkReleaseUploader
import com.example.core.license.LicenseManager
import com.example.data.APP_VERSION_NAME
import com.example.ui.theme.MagicAmber
import com.example.ui.theme.MagicAmberLight
import com.example.ui.theme.MagicBorder
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicCyanLight
import com.example.ui.theme.MagicEmerald
import com.example.ui.theme.MagicEmeraldLight
import com.example.ui.theme.MagicRose
import com.example.ui.theme.MagicRoseLight
import com.example.ui.theme.MagicSurfaceCard
import com.example.ui.theme.MagicSurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AdminApkReleaseCard(
    onPublishedUrl: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val currentRelease by LicenseManager.latestApkReleaseFlow.collectAsStateWithLifecycle()
    val installedVersionCode = remember { com.example.BuildConfig.VERSION_CODE.toLong() }

    var releaseNotes by remember {
        mutableStateOf("Cập nhật bản mới tối ưu hiệu năng, sửa lỗi và nâng cấp trải nghiệm mượt mà.")
    }
    var autoUpdateOldDevices by remember(currentRelease?.autoUpdateEnabled) {
        mutableStateOf(currentRelease?.autoUpdateEnabled ?: true)
    }
    var alsoBroadcastUpdate by remember { mutableStateOf(true) }

    var isUploading by remember { mutableStateOf(false) }
    var uploadProgress by remember { mutableStateOf<AdminApkReleaseUploader.UploadProgress?>(null) }
    var statusMessage by remember { mutableStateOf<String?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var uploadJob by remember { mutableStateOf<Job?>(null) }

    fun launchUploadTask(prepare: suspend () -> Result<AdminApkReleaseUploader.InspectedLocalApk>) {
        uploadJob?.cancel()
        errorMessage = null
        statusMessage = "🔍 Đang kiểm tra tệp APK..."
        isUploading = true
        uploadProgress = null

        uploadJob = scope.launch {
            try {
                val preparedResult = prepare()
                val apkInfo = preparedResult.getOrElse { err ->
                    isUploading = false
                    statusMessage = null
                    errorMessage = err.message ?: "Không thể đọc tệp APK."
                    return@launch
                }

                val sizeMb = String.format(Locale.US, "%.1f MB", apkInfo.sizeBytes / (1024.0 * 1024.0))
                statusMessage = "☁️ Đang tải v${apkInfo.versionName} (build ${apkInfo.versionCode} • $sizeMb) lên đám mây..."

                val uploadResult = AdminApkReleaseUploader.uploadApkToCloud(
                    context = context,
                    apk = apkInfo,
                    onProgress = { p -> uploadProgress = p }
                )

                isUploading = false
                when (uploadResult) {
                    is AdminApkReleaseUploader.UploadResult.Success -> {
                        LicenseManager.publishLatestApkRelease(
                            context = context,
                            downloadUrl = uploadResult.downloadUrl,
                            versionCode = apkInfo.versionCode,
                            versionName = apkInfo.versionName,
                            sizeBytes = apkInfo.sizeBytes,
                            releaseNotes = releaseNotes,
                            hostLabel = uploadResult.hostLabel,
                            autoUpdateEnabled = autoUpdateOldDevices,
                            alsoSendUpdateBroadcast = alsoBroadcastUpdate
                        )
                        onPublishedUrl(uploadResult.downloadUrl)
                        statusMessage = "✅ Đã phát hành v${apkInfo.versionName} (build ${apkInfo.versionCode}) lên ${uploadResult.hostLabel}! Mọi máy bản cũ sẽ tự động cập nhật."
                        Toast.makeText(
                            context,
                            "✅ Đã phát hành APK v${apkInfo.versionName} tới toàn bộ thiết bị!",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                    is AdminApkReleaseUploader.UploadResult.Error -> {
                        statusMessage = null
                        errorMessage = uploadResult.message
                    }
                }
            } catch (e: CancellationException) {
                isUploading = false
                statusMessage = "Đã hủy tải tệp APK lên."
                throw e
            } catch (e: Throwable) {
                isUploading = false
                statusMessage = null
                errorMessage = "Lỗi phát hành APK: ${e.message ?: "Không xác định"}"
            }
        }
    }

    // Bộ chọn tệp .APK qua Android SAF (0 quyền bộ nhớ)
    val apkPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            launchUploadTask {
                AdminApkReleaseUploader.prepareApkFromUri(context, uri)
            }
        }
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
        border = BorderStroke(
            1.2.dp,
            if (currentRelease != null) MagicEmerald else MagicAmber
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.SystemUpdate,
                        contentDescription = null,
                        tint = MagicEmeraldLight,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "[Ô 1.0] ☁️ TẢI LÊN APK BẢN MỚI NHẤT (CẬP NHẬT TỰ ĐỘNG)",
                        color = MagicEmeraldLight,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Black
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(
                            if (currentRelease != null) MagicEmerald.copy(alpha = 0.2f)
                            else MagicAmber.copy(alpha = 0.2f)
                        )
                        .border(
                            1.dp,
                            if (currentRelease != null) MagicEmerald else MagicAmber,
                            RoundedCornerShape(6.dp)
                        )
                        .padding(horizontal = 7.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = if (currentRelease != null) "🟢 v${currentRelease?.versionName}" else "⚪ CHƯA ÚP",
                        color = if (currentRelease != null) MagicEmeraldLight else MagicAmberLight,
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            Text(
                text = "Admin chọn tệp .APK mới để đẩy thẳng lên mây. Máy dùng bản cũ hơn sẽ tự động tải & cài thẳng, hoặc người dùng bấm 'Bản cập nhật' sẽ tải cài ngay lập tức.",
                color = TextSecondary,
                fontSize = 10.5.sp,
                lineHeight = 15.sp
            )

            // Trạng thái bản APK đang phát hành trên Cloud
            val published = currentRelease
            if (published != null && published.downloadUrl.isNotBlank()) {
                val sizeMb = if (published.sizeBytes > 0L) {
                    String.format(Locale.US, "%.1f MB", published.sizeBytes / (1024.0 * 1024.0))
                } else "—"
                val formattedTime = remember(published.uploadedAtMs) {
                    if (published.uploadedAtMs > 0L) {
                        SimpleDateFormat("HH:mm dd/MM/yyyy", Locale.getDefault()).format(Date(published.uploadedAtMs))
                    } else "Vừa phát hành"
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(MagicEmerald.copy(alpha = 0.1f))
                        .border(1.dp, MagicEmerald.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = MagicEmeraldLight,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "Đang phát hành: v${published.versionName} (build ${published.versionCode})",
                                color = MagicEmeraldLight,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        OutlinedButton(
                            onClick = {
                                LicenseManager.clearLatestApkRelease(context)
                                statusMessage = "Đã gỡ bản APK trên mây."
                                errorMessage = null
                            },
                            enabled = !isUploading,
                            modifier = Modifier
                                .heightIn(min = 32.dp)
                                .testTag("admin_clear_cloud_apk_btn"),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            border = BorderStroke(1.dp, MagicRose.copy(alpha = 0.6f))
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Gỡ bản Cloud",
                                tint = MagicRoseLight,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text("Gỡ bản", color = MagicRoseLight, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Text(
                        text = "📦 $sizeMb • ☁️ ${published.hostLabel.ifBlank { "Cloud CDN" }} • 🕒 $formattedTime",
                        color = MagicCyanLight,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = published.downloadUrl,
                        color = TextMuted,
                        fontSize = 9.5.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Nội dung ghi chú bản cập nhật
            OutlinedTextField(
                value = releaseNotes,
                onValueChange = { releaseNotes = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("admin_apk_release_notes_input"),
                label = { Text("Ghi chú bản cập nhật gửi tới người dùng", fontSize = 10.5.sp) },
                minLines = 2,
                maxLines = 3,
                enabled = !isUploading,
                shape = RoundedCornerShape(8.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MagicEmerald,
                    unfocusedBorderColor = MagicBorder,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedContainerColor = MagicSurfaceCard,
                    unfocusedContainerColor = MagicSurfaceCard
                )
            )

            // Tùy chọn tự động tải & cài trên máy bản cũ
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(MagicSurfaceCard)
                    .border(1.dp, MagicBorder, RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "⚡ Tự động tải & cài trên máy bản cũ",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Máy có mã build nhỏ hơn sẽ tự mở tải & cài thẳng khi mở app",
                        color = TextMuted,
                        fontSize = 9.8.sp
                    )
                }
                Switch(
                    checked = autoUpdateOldDevices,
                    onCheckedChange = { enabled ->
                        autoUpdateOldDevices = enabled
                        if (currentRelease != null) {
                            LicenseManager.setLatestApkAutoUpdateEnabled(context, enabled)
                        }
                    },
                    modifier = Modifier.testTag("admin_apk_auto_update_switch"),
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color(0xFF020617),
                        checkedTrackColor = MagicEmerald
                    )
                )
            }

            // Tùy chọn gửi kèm thông báo Broadcast UPDATE
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(MagicSurfaceCard)
                    .border(1.dp, MagicBorder, RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "📢 Tự động phát thông báo toàn cầu khi tải xong",
                    color = TextSecondary,
                    fontSize = 10.8.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
                Switch(
                    checked = alsoBroadcastUpdate,
                    onCheckedChange = { alsoBroadcastUpdate = it },
                    enabled = !isUploading,
                    modifier = Modifier.testTag("admin_apk_broadcast_switch"),
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color(0xFF020617),
                        checkedTrackColor = MagicCyan
                    )
                )
            }

            // Thanh tiến trình tải lên Cloud
            if (isUploading) {
                val p = uploadProgress
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(MagicCyan.copy(alpha = 0.12f))
                        .border(1.dp, MagicCyan.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val mbDone = (p?.uploadedBytes ?: 0L) / (1024.0 * 1024.0)
                    val mbTotal = (p?.totalBytes ?: 0L) / (1024.0 * 1024.0)
                    val pctText = if (p != null) "${p.percent}%" else "..."
                    val speedText = if (p != null && p.speedKbps > 0) " • ${p.speedKbps} KB/s" else ""

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "☁️ $pctText — ${p?.stageLabel ?: "Đang chuẩn bị..."}",
                            color = MagicCyanLight,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.weight(1f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = String.format(Locale.US, "%.1f/%.1f MB%s", mbDone, mbTotal, speedText),
                            color = TextSecondary,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    if (p != null && p.totalBytes > 0L) {
                        LinearProgressIndicator(
                            progress = { (p.percent / 100f).coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(7.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = MagicEmerald,
                            trackColor = Color(0xFF1E293B)
                        )
                    } else {
                        LinearProgressIndicator(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(7.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = MagicCyan,
                            trackColor = Color(0xFF1E293B)
                        )
                    }

                    OutlinedButton(
                        onClick = {
                            uploadJob?.cancel()
                            isUploading = false
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 40.dp)
                            .testTag("admin_cancel_apk_upload_btn"),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, MagicRose)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = null, tint = MagicRoseLight, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(5.dp))
                        Text("Hủy Tải Lên", color = MagicRoseLight, fontSize = 11.sp, fontWeight = FontWeight.Black)
                    }
                }
            }

            if (!statusMessage.isNullOrBlank()) {
                Text(
                    text = statusMessage.orEmpty(),
                    color = MagicEmeraldLight,
                    fontSize = 10.8.sp,
                    fontWeight = FontWeight.Bold,
                    lineHeight = 15.sp
                )
            }

            if (!errorMessage.isNullOrBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(MagicRose.copy(alpha = 0.14f))
                        .border(1.dp, MagicRose.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                        .padding(8.dp)
                ) {
                    Text(
                        text = "⚠️ ${errorMessage.orEmpty()}",
                        color = MagicRoseLight,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        lineHeight = 15.sp
                    )
                }
            }

            // Hai nút hành động chính: Chọn file .APK từ máy hoặc Tải thẳng bản đang cài trên máy Admin
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        try {
                            apkPickerLauncher.launch(arrayOf("application/vnd.android.package-archive", "*/*"))
                        } catch (_: Throwable) {
                            Toast.makeText(context, "Không thể mở trình chọn tệp APK.", Toast.LENGTH_SHORT).show()
                        }
                    },
                    enabled = !isUploading,
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                        .testTag("admin_pick_apk_upload_btn"),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MagicEmerald,
                        contentColor = Color(0xFF020617)
                    )
                ) {
                    Icon(Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = "Chọn File .APK Úp Lên",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                OutlinedButton(
                    onClick = {
                        launchUploadTask {
                            AdminApkReleaseUploader.prepareCurrentInstalledApk(context)
                        }
                    },
                    enabled = !isUploading,
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                        .testTag("admin_upload_installed_apk_btn"),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                    border = BorderStroke(1.dp, MagicCyan)
                ) {
                    Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = MagicCyanLight, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = "Úp Bản Đang Cài ($APP_VERSION_NAME • b$installedVersionCode)",
                        color = MagicCyanLight,
                        fontSize = 10.2.sp,
                        fontWeight = FontWeight.Black,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}
