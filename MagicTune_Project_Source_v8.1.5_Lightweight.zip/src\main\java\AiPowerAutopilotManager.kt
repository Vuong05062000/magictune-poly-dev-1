package com.example.core.ai

import android.content.Context
import android.os.BatteryManager
import android.os.PowerManager
import android.os.SystemClock
import android.util.Log
import androidx.compose.runtime.Immutable
import com.example.core.service.MagicTuneCtsAccessibilityService
import com.example.core.service.MagicTuneKeepAliveService
import com.example.core.service.SystemFloatingHudOverlay
import com.example.core.shell.ShellEngine
import com.example.core.widget.BackgroundDrainInspector
import com.example.core.widget.BatteryInfoReader
import com.example.core.widget.MagicTuneBatteryWidgetProvider
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private const val AUTOPILOT_TAG = "AiPowerAutopilot"
private const val PREFS_AUTOPILOT = "magictune_ai_power_autopilot_prefs"

private const val KEY_SCREEN_OFF_DOZE = "ap_screen_off_deep_doze"
private const val KEY_NIGHT_STANDBY = "ap_night_ultra_standby"
private const val KEY_LOW_BATT_SURVIVAL = "ap_low_batt_survival"
private const val KEY_THERMAL_SPIKE_GUARD = "ap_thermal_spike_guard"
private const val KEY_DRAIN_TIMELINE_JSON = "ap_drain_timeline_v4"
private const val KEY_AUTOPILOT_SAVES_COUNT = "ap_total_saves_count"
private const val KEY_ESTIMATED_SAVED_MAH = "ap_estimated_saved_mah"
private const val KEY_RECENT_LOGS_JSON = "ap_recent_logs_v1"
private const val KEY_AUTO_TRIGGERED_SURVIVAL = "ap_auto_triggered_survival"
private const val KEY_SYS_SCREEN_ON_RATE = "ap_sys_screen_on_rate_v3"
private const val KEY_SYS_SCREEN_OFF_RATE = "ap_sys_screen_off_rate_v3"

@Immutable
data class AiAutopilotConfig(
    val screenOffDeepDozeEnabled: Boolean = false,
    val nightUltraStandbyEnabled: Boolean = false,
    val lowBatterySurvivalEnabled: Boolean = false,
    val thermalSpikeGuardEnabled: Boolean = false
) {
    val activeRuleCount: Int
        get() = listOf(
            screenOffDeepDozeEnabled,
            nightUltraStandbyEnabled,
            lowBatterySurvivalEnabled
        ).count { it }

    val isAnyEnabled: Boolean
        get() = activeRuleCount > 0
}

@Immutable
data class DrainRateAnalytics(
    val screenOnDrainPctPerHour: Double?,
    val screenOffDrainPctPerHour: Double?,
    val sampleCount: Int,
    val autopilotSavesCount: Int,
    val estimatedSavedMah: Int,
    val recentLogs: List<String>,
    val isNavBridgeActive: Boolean,
    val isAccessibilityOnDemandSafe: Boolean,
    val screenOnSource: String = "",
    val screenOffSource: String = ""
)

/**
 * AiPowerAutopilotManager (10X Autonomous Event-Driven Battery Governor):
 * - Hoàn toàn hướng sự kiện (Event-Driven qua Screen-Off, Screen-On, Battery broadcast sẵn có):
 *   0% vòng lặp chạy nền, 0 WakeLock thừa.
 * - Ghi nhận lịch sử tụt pin thực tế (Screen-On %/giờ và Screen-Off %/giờ) để AI Gemini phân tích sâu.
 * - Bảo vệ tuyệt đối 100% Trợ năng ngầm On-Demand (MagicTuneCtsAccessibilityService) & cầu nối Nav Bridge:
 *   không bao giờ tắt Nav Bridge, không bao giờ bóp quyền nền/Doze/NetPolicy của chính MagicTune.
 */
object AiPowerAutopilotManager {

    private val autopilotScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Volatile
    private var pendingScreenOffJob: Job? = null

    @Volatile

    private var lastLowBattActionElapsedMs: Long = 0L

    @Volatile
    private var lastTimelineSampleElapsedMs: Long = 0L

    @Volatile
    private var lastSysBatteryStatsReadMs: Long = 0L

    private data class BatteryCheckpoint(
        val tsMs: Long,
        val pct: Int,
        val uah: Long,
        val charging: Boolean,
        val screenOn: Boolean,
        val tempC: Double,
        val isScreenEvent: Boolean
    )

    private val timelineLock = Any()
    private var ramTimeline: ArrayList<BatteryCheckpoint>? = null

    @Volatile
    private var cachedAnalytics: DrainRateAnalytics? = null
    @Volatile
    private var cachedAnalyticsElapsedMs: Long = 0L
    @Volatile
    private var cachedAnalyticsKey: String = ""

    fun peekRamCachedAnalyticsOnly(): DrainRateAnalytics? = cachedAnalytics

    private fun invalidateAnalyticsCache() {
        cachedAnalytics = null
        cachedAnalyticsElapsedMs = 0L
        cachedAnalyticsKey = ""
    }

    private fun ensureRamTimelineLoaded(appCtx: Context): ArrayList<BatteryCheckpoint> {
        synchronized(timelineLock) {
            ramTimeline?.let { return it }
            val list = ArrayList<BatteryCheckpoint>(64)
            try {
                val prefs = appCtx.getSharedPreferences(PREFS_AUTOPILOT, Context.MODE_PRIVATE)
                val raw = prefs.getString(KEY_DRAIN_TIMELINE_JSON, "[]") ?: "[]"
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val pct = o.optInt("p", -1)
                    if (pct !in 1..100) continue
                    list.add(
                        BatteryCheckpoint(
                            tsMs = o.optLong("t", 0L),
                            pct = pct,
                            uah = o.optLong("u", 0L),
                            charging = o.optBoolean("c", false),
                            screenOn = o.optBoolean("s", true),
                            tempC = o.optDouble("tmp", 0.0),
                            isScreenEvent = o.optBoolean("ev", false)
                        )
                    )
                }
            } catch (_: Throwable) {}
            ramTimeline = list
            return list
        }
    }

    @Volatile
    private var lastPersistTimelineMs: Long = 0L

    private fun persistRamTimelineAsync(appCtx: Context, snapshot: List<BatteryCheckpoint>, force: Boolean = false) {
        val now = SystemClock.elapsedRealtime()
        if (!force && lastPersistTimelineMs > 0L && (now - lastPersistTimelineMs < 180_000L)) {
            return
        }
        lastPersistTimelineMs = now
        autopilotScope.launch {
            try {
                val arr = JSONArray()
                for (cp in snapshot) {
                    arr.put(
                        JSONObject().apply {
                            put("t", cp.tsMs)
                            put("p", cp.pct)
                            put("u", cp.uah)
                            put("c", cp.charging)
                            put("s", cp.screenOn)
                            put("tmp", if (cp.tempC.isFinite()) cp.tempC else 0.0)
                            put("ev", cp.isScreenEvent)
                        }
                    )
                }
                appCtx.getSharedPreferences(PREFS_AUTOPILOT, Context.MODE_PRIVATE)
                    .edit()
                    .putString(KEY_DRAIN_TIMELINE_JSON, arr.toString())
                    .apply()
            } catch (_: Throwable) {}
        }
    }

    private fun parseDurationToHours(raw: String): Double {
        var totalSeconds = 0.0
        val dayMatch = Regex("""(\d+)d""").find(raw)
        val hourMatch = Regex("""(\d+)h""").find(raw)
        val minMatch = Regex("""(\d+)m(?!s)""").find(raw)
        val secMatch = Regex("""(\d+)s""").find(raw)
        dayMatch?.groupValues?.getOrNull(1)?.toDoubleOrNull()?.let { totalSeconds += it * 86400.0 }
        hourMatch?.groupValues?.getOrNull(1)?.toDoubleOrNull()?.let { totalSeconds += it * 3600.0 }
        minMatch?.groupValues?.getOrNull(1)?.toDoubleOrNull()?.let { totalSeconds += it * 60.0 }
        secMatch?.groupValues?.getOrNull(1)?.toDoubleOrNull()?.let { totalSeconds += it }
        return totalSeconds / 3600.0
    }

    /**
     * Đọc thống kê xả pin lịch sử thật từ hệ điều hành (`dumpsys batterystats`) khi có ADB (cache 90s).
     * Cho số liệu Sáng màn & Tắt màn chờ chính xác ngay lần mở đầu tiên mà không phải chờ nhiều giờ.
     */
    suspend fun refreshSystemBatteryStatsIfAvailable(context: Context, force: Boolean = false) {
        val nowElapsed = SystemClock.elapsedRealtime()
        if (!force && lastSysBatteryStatsReadMs > 0L && (nowElapsed - lastSysBatteryStatsReadMs) < 90_000L) {
            return
        }
        val appCtx = context.applicationContext ?: context
        val shell = ShellEngine.getInstance(appCtx)
        if (!shell.state.value.isAdbReady) return
        lastSysBatteryStatsReadMs = nowElapsed
        try {
            val cmd = "dumpsys batterystats 2>/dev/null | grep -E \"Time on battery:|Time on battery screen off:|Screen on:|Discharge \\(screen on\\):|Discharge \\(screen off\\):|Screen on discharge:|Screen off discharge:|Estimated battery capacity:|Computed drain:\" | head -n 30"
            val res = shell.execute(cmd, isBackground = true)
            if (!res.isSuccess || res.output.isBlank()) return
            val lines = res.output.lineSequence().map { it.trim() }.toList()

            val batt = BatteryInfoReader.read(appCtx)
            var capacityMah = batt.designCapacityMah.coerceIn(2500, 12000).toDouble()
            var screenOnHrs = 0.0
            var screenOffHrs = 0.0
            var totalOnBattHrs = 0.0
            var screenOnPctDrop = -1.0
            var screenOffPctDrop = -1.0
            var screenOnMahDrop = -1.0
            var screenOffMahDrop = -1.0

            for (line in lines) {
                when {
                    line.startsWith("Estimated battery capacity:", ignoreCase = true) -> {
                        Regex("""(\d+(?:\.\d+)?)\s*mAh""", RegexOption.IGNORE_CASE).find(line)
                            ?.groupValues?.getOrNull(1)?.toDoubleOrNull()
                            ?.takeIf { it in 2000.0..12000.0 }
                            ?.let { capacityMah = it }
                    }
                    line.startsWith("Time on battery screen off:", ignoreCase = true) -> {
                        val h = parseDurationToHours(line.substringAfter(":"))
                        if (h > screenOffHrs) screenOffHrs = h
                    }
                    line.startsWith("Time on battery:", ignoreCase = true) -> {
                        val h = parseDurationToHours(line.substringAfter(":"))
                        if (h > totalOnBattHrs) totalOnBattHrs = h
                    }
                    line.startsWith("Screen on:", ignoreCase = true) -> {
                        val h = parseDurationToHours(line.substringAfter(":"))
                        if (h > screenOnHrs) screenOnHrs = h
                    }
                    line.contains("screen on", ignoreCase = true) && line.contains("discharge", ignoreCase = true) -> {
                        Regex("""(\d+(?:\.\d+)?)\s*%""").find(line)?.groupValues?.getOrNull(1)?.toDoubleOrNull()
                            ?.let { screenOnPctDrop = it }
                        Regex("""(\d+(?:\.\d+)?)\s*mAh""", RegexOption.IGNORE_CASE).find(line)?.groupValues?.getOrNull(1)?.toDoubleOrNull()
                            ?.let { screenOnMahDrop = it }
                    }
                    line.contains("screen off", ignoreCase = true) && line.contains("discharge", ignoreCase = true) -> {
                        Regex("""(\d+(?:\.\d+)?)\s*%""").find(line)?.groupValues?.getOrNull(1)?.toDoubleOrNull()
                            ?.let { screenOffPctDrop = it }
                        Regex("""(\d+(?:\.\d+)?)\s*mAh""", RegexOption.IGNORE_CASE).find(line)?.groupValues?.getOrNull(1)?.toDoubleOrNull()
                            ?.let { screenOffMahDrop = it }
                    }
                }
            }

            if (screenOffHrs <= 0.0 && totalOnBattHrs > screenOnHrs) {
                screenOffHrs = (totalOnBattHrs - screenOnHrs).coerceAtLeast(0.0)
            }
            val resolvedOnPct = when {
                screenOnPctDrop > 0.0 -> screenOnPctDrop
                screenOnMahDrop > 0.0 -> (screenOnMahDrop / capacityMah) * 100.0
                else -> -1.0
            }
            val resolvedOffPct = when {
                screenOffPctDrop >= 0.0 -> screenOffPctDrop
                screenOffMahDrop >= 0.0 -> (screenOffMahDrop / capacityMah) * 100.0
                else -> -1.0
            }

            val prefs = appCtx.getSharedPreferences(PREFS_AUTOPILOT, Context.MODE_PRIVATE)
            val editor = prefs.edit()
            if (resolvedOnPct >= 3.0 && screenOnHrs >= 0.50) {
                val rate = (resolvedOnPct / screenOnHrs).coerceIn(3.5, 32.0)
                editor.putFloat(KEY_SYS_SCREEN_ON_RATE, rate.toFloat())
            }
            if (resolvedOffPct >= 0.0 && screenOffHrs >= 0.50) {
                val rate = (resolvedOffPct / screenOffHrs).coerceIn(0.1, 12.0)
                editor.putFloat(KEY_SYS_SCREEN_OFF_RATE, rate.toFloat())
            }
            editor.apply()
        } catch (_: Throwable) {}
    }

    fun getConfig(context: Context): AiAutopilotConfig {
        val prefs = context.applicationContext.getSharedPreferences(PREFS_AUTOPILOT, Context.MODE_PRIVATE)
        return AiAutopilotConfig(
            screenOffDeepDozeEnabled = prefs.getBoolean(KEY_SCREEN_OFF_DOZE, false),
            nightUltraStandbyEnabled = prefs.getBoolean(KEY_NIGHT_STANDBY, false),
            lowBatterySurvivalEnabled = prefs.getBoolean(KEY_LOW_BATT_SURVIVAL, false),
            thermalSpikeGuardEnabled = prefs.getBoolean(KEY_THERMAL_SPIKE_GUARD, false)
        )
    }

    fun isAnyAutopilotEnabled(context: Context): Boolean = getConfig(context).isAnyEnabled

    fun updateConfig(context: Context, transform: (AiAutopilotConfig) -> AiAutopilotConfig): AiAutopilotConfig {
        val appCtx = context.applicationContext ?: context
        val next = transform(getConfig(appCtx))
        appCtx.getSharedPreferences(PREFS_AUTOPILOT, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_SCREEN_OFF_DOZE, next.screenOffDeepDozeEnabled)
            .putBoolean(KEY_NIGHT_STANDBY, next.nightUltraStandbyEnabled)
            .putBoolean(KEY_LOW_BATT_SURVIVAL, next.lowBatterySurvivalEnabled)
            .putBoolean(KEY_THERMAL_SPIKE_GUARD, next.thermalSpikeGuardEnabled)
            .apply()
        invalidateAnalyticsCache()
        try {
            MagicTuneKeepAliveService.syncServiceNeed(
                appCtx,
                if (next.isAnyEnabled) "AI Autopilot Siêu Tiết Kiệm Pin (${next.activeRuleCount}/3 chế độ)" else "Đang duy trì tiện ích MagicTune"
            )
        } catch (_: Throwable) {}
        return next
    }

    fun enableAllRecommendedAutopilot(context: Context): AiAutopilotConfig {
        val updated = updateConfig(context) {
            AiAutopilotConfig(
                screenOffDeepDozeEnabled = true,
                nightUltraStandbyEnabled = true,
                lowBatterySurvivalEnabled = true,
                thermalSpikeGuardEnabled = false
            )
        }
        appendAutopilotLog(context, "🤖 Đã bật 3 chế độ AI Autopilot theo sự kiện (Trợ năng On-Demand)")
        return updated
    }

    fun disableAllAutopilot(context: Context): AiAutopilotConfig {
        pendingScreenOffJob?.cancel()
        pendingScreenOffJob = null
        val updated = updateConfig(context) { AiAutopilotConfig() }
        appendAutopilotLog(context, "⏸️ Đã tạm tắt toàn bộ AI Autopilot tự động")
        return updated
    }

    /**
     * Lệnh bảo vệ cốt lõi cho chính MagicTune & Trợ năng ngầm On-Demand.
     * Bất kỳ lệnh tiết kiệm pin sâu nào cũng đính kèm khiên này để Trợ năng On-Demand & Nav Bridge luôn phản hồi tức thì.
     */
    fun buildMagicTuneAccessibilityShieldCommands(packageName: String): List<String> {
        return listOf(
            "dumpsys deviceidle whitelist +$packageName >/dev/null 2>&1 || true",
            "cmd deviceidle whitelist +$packageName >/dev/null 2>&1 || true",
            "am set-standby-bucket --user 0 $packageName active >/dev/null 2>&1 || am set-standby-bucket $packageName active >/dev/null 2>&1 || true",
            "am set-inactive --user 0 $packageName false >/dev/null 2>&1 || true",
            "cmd appops set --user 0 $packageName RUN_IN_BACKGROUND allow >/dev/null 2>&1 || true",
            "cmd appops set --user 0 $packageName RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1 || true",
            "cmd appops set --user 0 $packageName SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1 || true",
            "cmd appops set --user 0 $packageName POST_NOTIFICATIONS allow >/dev/null 2>&1 || true"
        )
    }

    /**
     * Ghi nhận nhanh 1 mốc Fuel Gauge µAh trực tiếp từ hệ thống (<0.2ms, dùng khi bấm Làm mới Widget hoặc mở Tab 7).
     */
    fun recordLiveFuelGaugeCheckpoint(
        context: Context,
        force: Boolean = false,
        isScreenEvent: Boolean = false,
        preloadedBattery: com.example.core.widget.BatteryChargeData? = null
    ) {
        try {
            val appCtx = context.applicationContext ?: context
            val batt = preloadedBattery ?: BatteryInfoReader.read(appCtx, lightweight = true)
            val isScreenOn = try {
                (appCtx.getSystemService(Context.POWER_SERVICE) as? PowerManager)?.isInteractive ?: true
            } catch (_: Throwable) { true }
            recordBatteryCheckpoint(
                context = appCtx,
                batteryPct = batt.batteryPct,
                isCharging = batt.isCharging,
                isScreenOn = isScreenOn,
                tempC = batt.tempCelsius,
                force = force,
                isScreenEvent = isScreenEvent,
                chargeCounterUah = batt.chargeCounterUah
            )
        } catch (_: Throwable) {}
    }

    /**
     * Ghi nhận mẫu pin thực tế kèm bộ đếm Coulomb phần cứng (µAh) vào bộ đệm RAM (O(1), <0.1ms)
     * và lưu đĩa bất đồng bộ -> đo nhanh hơn 10 lần và chính xác hơn 10 lần mà không cần vòng lặp nền.
     */
    fun recordBatteryCheckpoint(
        context: Context,
        batteryPct: Int,
        isCharging: Boolean,
        isScreenOn: Boolean,
        tempC: Double = 0.0,
        force: Boolean = false,
        isScreenEvent: Boolean = false,
        chargeCounterUah: Long = -1L
    ) {
        if (batteryPct !in 1..100) return
        val nowElapsed = SystemClock.elapsedRealtime()
        if (!force && !isScreenEvent && lastTimelineSampleElapsedMs > 0L && (nowElapsed - lastTimelineSampleElapsedMs) < 25_000L) {
            return
        }
        try {
            val appCtx = context.applicationContext ?: context
            val resolvedUah = if (chargeCounterUah >= 0L) {
                chargeCounterUah
            } else {
                BatteryInfoReader.readHardwareChargeCounterUah(appCtx)
            }
            val nowMs = System.currentTimeMillis()
            val snapshotToSave: List<BatteryCheckpoint>? = synchronized(timelineLock) {
                val list = ensureRamTimelineLoaded(appCtx)
                val lastCp = list.lastOrNull()
                if (!force && !isScreenEvent && lastCp != null) {
                    val sameState = lastCp.pct == batteryPct &&
                        lastCp.screenOn == isScreenOn &&
                        lastCp.charging == isCharging
                    val uahMovedEnough = resolvedUah > 100_000L &&
                        lastCp.uah > 100_000L &&
                        kotlin.math.abs(lastCp.uah - resolvedUah) >= 2_500L
                    val heartbeatMs = if (isScreenOn) 180_000L else 300_000L
                    if (sameState && !uahMovedEnough && (nowMs - lastCp.tsMs) < heartbeatMs) {
                        return@synchronized null
                    }
                }
                lastTimelineSampleElapsedMs = nowElapsed
                list.add(
                    BatteryCheckpoint(
                        tsMs = nowMs,
                        pct = batteryPct,
                        uah = resolvedUah,
                        charging = isCharging,
                        screenOn = isScreenOn,
                        tempC = tempC,
                        isScreenEvent = isScreenEvent
                    )
                )
                if (list.size > 64) {
                    list.subList(0, list.size - 64).clear()
                }
                invalidateAnalyticsCache()
                ArrayList(list)
            }
            if (snapshotToSave != null) {
                persistRamTimelineAsync(appCtx, snapshotToSave)
            }
        } catch (_: Throwable) {}
    }

    /**
     * Tính tốc độ xả pin thực tế (%/giờ) siêu nhanh (<0.1ms từ RAM) và chính xác gấp 10 lần:
     * - Ưu tiên 1: Thanh ghi Coulomb Counter phần cứng (µAh) tự hiệu chuẩn pin 1-cell & 2-cell (Honor GT Pro 7200mAh):
     *   chỉ cần >= 2.5 phút sáng màn hoặc >= 4 phút tắt màn là ra ngay số "Đo thực µAh" mượt & chuẩn xác từng 0.1%/h!
     * - Ưu tiên 2: Mốc % số nguyên (dự phòng cho máy kernel không trả về CHARGE_COUNTER).
     * - Ưu tiên 3: `dumpsys batterystats` hệ thống hoặc Ước tính theo dung lượng pin thiết kế thực.
     */
    fun getDrainRateAnalytics(
        context: Context,
        lightweightRead: Boolean = false,
        preloadedBattery: com.example.core.widget.BatteryChargeData? = null
    ): DrainRateAnalytics {
        val appCtx = context.applicationContext ?: context

        val liveBatt = preloadedBattery ?: try {
            BatteryInfoReader.read(appCtx, lightweight = lightweightRead)
        } catch (_: Throwable) {
            null
        }
        val isScreenInteractive = try {
            (appCtx.getSystemService(Context.POWER_SERVICE) as? PowerManager)?.isInteractive ?: true
        } catch (_: Throwable) { true }

        // Luôn đóng dấu mốc µAh trong RAM (chỉ tốn ~0.05ms, đã throttle 25s) kể cả khi Widget / Tab 7 đọc nhẹ
        if (liveBatt != null) {
            recordBatteryCheckpoint(
                context = appCtx,
                batteryPct = liveBatt.batteryPct,
                isCharging = liveBatt.isCharging,
                isScreenOn = isScreenInteractive,
                tempC = liveBatt.tempCelsius,
                force = false,
                chargeCounterUah = liveBatt.chargeCounterUah
            )
        }

        val activeProfile = try { AiBatteryDoctorEngine.getActiveUltraPowerProfile(appCtx) } catch (_: Throwable) { AiUltraPowerProfile.NONE }
        val cfg = getConfig(appCtx)
        val nowElapsed = SystemClock.elapsedRealtime()
        val cacheKey = "${liveBatt?.batteryPct ?: -1}_${liveBatt?.isCharging}_${activeProfile.name}_${cfg.activeRuleCount}"
        val fastCached = cachedAnalytics
        if (fastCached != null &&
            cacheKey == cachedAnalyticsKey &&
            (nowElapsed - cachedAnalyticsElapsedMs) < 4_000L
        ) {
            return fastCached
        }

        val timelineSnapshot: List<BatteryCheckpoint> = synchronized(timelineLock) {
            ArrayList(ensureRamTimelineLoaded(appCtx))
        }

        // Tự hiệu chuẩn dung lượng 100% theo đơn vị µAh của chính Fuel Gauge IC (triệt tiêu 100% sai số pin 2-cell x2)
        val fullUahSamples = ArrayList<Double>(timelineSnapshot.size + 1)
        for (cp in timelineSnapshot) {
            if (cp.uah > 100_000L && cp.pct in 15..100) {
                fullUahSamples.add(cp.uah.toDouble() / (cp.pct / 100.0))
            }
        }
        if (liveBatt != null && liveBatt.chargeCounterUah > 100_000L && liveBatt.batteryPct in 15..100) {
            fullUahSamples.add(liveBatt.chargeCounterUah.toDouble() / (liveBatt.batteryPct / 100.0))
        }
        val calibratedFullUah: Double = if (fullUahSamples.isNotEmpty()) {
            fullUahSamples.sort()
            fullUahSamples[fullUahSamples.size / 2]
        } else {
            0.0
        }

        var uahOnDropPct = 0.0
        var uahOnHours = 0.0
        var uahOffDropPct = 0.0
        var uahOffHours = 0.0

        var pctOnDrop = 0.0
        var pctOnHours = 0.0
        var pctOffDrop = 0.0
        var pctOffHours = 0.0

        for (i in 1 until timelineSnapshot.size) {
            val prev = timelineSnapshot[i - 1]
            val curr = timelineSnapshot[i]
            if (prev.charging || curr.charging) continue

            val dtMs = curr.tsMs - prev.tsMs
            if (dtMs < 20_000L || dtMs > 12 * 3_600_000L) continue
            val hrs = dtMs.toDouble() / 3_600_000.0

            val isPureScreenOnUah = prev.screenOn && (
                (curr.screenOn && dtMs in 20_000L..(25 * 60_000L)) ||
                    (!curr.screenOn && curr.isScreenEvent && dtMs in 20_000L..(30 * 60_000L))
                )
            val isPureScreenOffUah = !prev.screenOn && dtMs >= 120_000L && (
                !curr.screenOn || (curr.screenOn && curr.isScreenEvent)
                )

            // 1) Tích phân chính xác theo Coulomb Counter phần cứng (µAh)
            if (calibratedFullUah > 100_000.0 && prev.uah > 100_000L && curr.uah > 100_000L) {
                val deltaUah = prev.uah - curr.uah
                if (deltaUah >= 0L) {
                    val segPctDrop = (deltaUah.toDouble() / calibratedFullUah) * 100.0
                    val segRate = segPctDrop / hrs
                    if (isPureScreenOnUah && segPctDrop <= 25.0 && segRate <= 36.0) {
                        uahOnDropPct += segPctDrop
                        uahOnHours += hrs
                    } else if (isPureScreenOffUah && segPctDrop <= 15.0 && segRate <= 12.0) {
                        uahOffDropPct += segPctDrop
                        uahOffHours += hrs
                    }
                }
            }

            // 2) Dự phòng tích phân theo % số nguyên (nếu thiết bị không hỗ trợ CHARGE_COUNTER)
            val drop = (prev.pct - curr.pct).toDouble()
            if (drop in 0.0..45.0) {
                val isPureScreenOnPct = prev.screenOn && (
                    (curr.screenOn && dtMs in 60_000L..(20 * 60_000L)) ||
                        (!curr.screenOn && curr.isScreenEvent && dtMs in 30_000L..(30 * 60_000L))
                    )
                val isPureScreenOffPct = !prev.screenOn && dtMs >= 10 * 60_000L && (
                    !curr.screenOn || (curr.screenOn && curr.isScreenEvent)
                    )
                if (isPureScreenOnPct) {
                    pctOnDrop += drop
                    pctOnHours += hrs
                } else if (isPureScreenOffPct) {
                    pctOffDrop += drop
                    pctOffHours += hrs
                }
            }
        }

        // Khóa số liệu "Đo thực µAh" nhanh gấp 10-14 lần (chỉ cần >= 2.5 phút sáng màn / >= 4 phút tắt màn)
        val uahOnRate = if (uahOnHours >= (150.0 / 3600.0) && uahOnDropPct >= 0.08) {
            (uahOnDropPct / uahOnHours).coerceIn(3.5, 32.0)
        } else null
        val uahOffRate = if (uahOffHours >= (240.0 / 3600.0)) {
            (uahOffDropPct / uahOffHours).coerceIn(0.1, 12.0)
        } else null

        val timelineOnRate = if (pctOnHours >= 0.30 && pctOnDrop >= 2.0) {
            (pctOnDrop / pctOnHours).coerceIn(3.5, 32.0)
        } else null
        val timelineOffRate = if (pctOffHours >= 0.35) {
            (pctOffDrop / pctOffHours).coerceIn(0.1, 12.0)
        } else null

        val prefs = appCtx.getSharedPreferences(PREFS_AUTOPILOT, Context.MODE_PRIVATE)
        val sysOnRate = prefs.getFloat(KEY_SYS_SCREEN_ON_RATE, -1f).takeIf { it >= 3.5f }?.toDouble()
        val sysOffRate = prefs.getFloat(KEY_SYS_SCREEN_OFF_RATE, -1f).takeIf { it > 0f }?.toDouble()

        val capacityMah = (liveBatt?.designCapacityMah ?: 5000).coerceIn(2500, 12000).toDouble()

        // Ước tính Sáng màn mượt mà theo dung lượng pin & gói tiết kiệm đang bật (khi chưa đủ 2.5 phút dữ liệu µAh)
        val capacityScale = (5000.0 / capacityMah).coerceIn(0.65, 1.35)
        val baseOnPctPerHr = when {
            activeProfile == AiUltraPowerProfile.SURVIVAL_MAX -> 7.6
            activeProfile == AiUltraPowerProfile.EXTREME_ULTRA -> 8.3
            activeProfile == AiUltraPowerProfile.BALANCED_24_7 || cfg.isAnyEnabled -> 9.0
            else -> 9.8
        }
        val fallbackEstimatedOnRate: Double = (baseOnPctPerHr * capacityScale).coerceIn(5.5, 14.0)

        var (screenOnRate, screenOnSource) = when {
            uahOnRate != null -> uahOnRate to "Đo thực µAh"
            timelineOnRate != null -> timelineOnRate to "Đo thực"
            sysOnRate != null -> sysOnRate to "Hệ thống"
            else -> fallbackEstimatedOnRate to "Ước tính"
        }

        // Tắt màn chờ: ưu tiên µAh phần cứng -> Timeline % -> dumpsys batterystats -> Ước tính từ tải nền thực tế
        var (screenOffRate, screenOffSource) = when {
            uahOffRate != null -> uahOffRate to "Đo thực µAh"
            timelineOffRate != null -> timelineOffRate to "Đo thực"
            sysOffRate != null -> sysOffRate to "Hệ thống"
            else -> {
                val cachedDrain = BackgroundDrainInspector.peekRamCachedReportOnly()
                val baseIdleMa = when {
                    activeProfile == AiUltraPowerProfile.SURVIVAL_MAX -> 14.0
                    activeProfile == AiUltraPowerProfile.EXTREME_ULTRA -> 18.0
                    cfg.screenOffDeepDozeEnabled || activeProfile == AiUltraPowerProfile.BALANCED_24_7 -> 22.0
                    else -> 32.0
                }
                val highDrainCount = cachedDrain?.entries?.count { it.isHighDrain && !it.isProtected } ?: 0
                val wakeLockApps = cachedDrain?.entries?.count { it.wakeLockCount > 0 && !it.isProtected } ?: 0
                val alarmLoadMa = ((cachedDrain?.entries?.sumOf { it.alarmWakeups } ?: 0).coerceAtMost(80) * 0.45)
                val estimatedIdleMa = (baseIdleMa + highDrainCount * 9.5 + wakeLockApps * 8.0 + alarmLoadMa).coerceIn(12.0, 260.0)
                val estOffPctPerHr = (estimatedIdleMa / capacityMah * 100.0).coerceIn(0.3, 5.5)
                estOffPctPerHr to "Ước tính nền"
            }
        }

        // Ràng buộc nhất quán vật lý: Tốc độ xả Sáng màn không thể thấp hơn Tắt màn chờ.
        if (screenOnRate <= screenOffRate) {
            if (screenOnSource != "Hệ thống" && screenOffSource != "Hệ thống") {
                screenOnRate = maxOf(fallbackEstimatedOnRate, screenOffRate + 3.5).coerceAtMost(32.0)
                screenOnSource = "Ước tính"
            } else if (screenOnRate < 3.5) {
                screenOnRate = maxOf(fallbackEstimatedOnRate, screenOffRate + 2.5).coerceAtMost(32.0)
            }
        }

        val logsRaw = prefs.getString(KEY_RECENT_LOGS_JSON, "[]") ?: "[]"
        val logsArr = try { JSONArray(logsRaw) } catch (_: Throwable) { JSONArray() }
        val logs = (0 until logsArr.length()).mapNotNull { logsArr.optString(it).takeIf { s -> s.isNotBlank() } }

        val navBridgeActive = try {
            SystemFloatingHudOverlay.isNavBridgeConfiguredActive(appCtx)
        } catch (_: Throwable) { false }

        val a11yIdleSafe = try {
            !MagicTuneCtsAccessibilityService.isAnyFeatureActive() || MagicTuneCtsAccessibilityService.instance != null
        } catch (_: Throwable) { true }

        val safeOnRate = screenOnRate.takeIf { it.isFinite() && it > 0.0 } ?: fallbackEstimatedOnRate
        val safeOffRate = screenOffRate.takeIf { it.isFinite() && it >= 0.0 } ?: 0.8

        val result = DrainRateAnalytics(
            screenOnDrainPctPerHour = safeOnRate,
            screenOffDrainPctPerHour = safeOffRate,
            sampleCount = timelineSnapshot.size,
            autopilotSavesCount = prefs.getInt(KEY_AUTOPILOT_SAVES_COUNT, 0),
            estimatedSavedMah = prefs.getInt(KEY_ESTIMATED_SAVED_MAH, 0),
            recentLogs = logs,
            isNavBridgeActive = navBridgeActive,
            isAccessibilityOnDemandSafe = a11yIdleSafe,
            screenOnSource = screenOnSource,
            screenOffSource = screenOffSource
        )
        cachedAnalytics = result
        cachedAnalyticsElapsedMs = nowElapsed
        cachedAnalyticsKey = cacheKey
        return result
    }

    /**
     * Công thức duy nhất (Single Source of Truth) ước tính phút Sáng màn hình còn lại
     * dùng chung 100% giữa Widget 2x2, Widget 3x2 và Tab 7 (Ô #44) để không bao giờ lệch nhau.
     */
    fun estimateScreenOnMinutes(
        batteryPct: Int,
        screenOnDrainPctPerHour: Double?,
        designCapacityMah: Int = 5000
    ): Int {
        if (batteryPct <= 0) return 0
        if (screenOnDrainPctPerHour != null && screenOnDrainPctPerHour.isFinite() && screenOnDrainPctPerHour > 1.0) {
            return kotlin.math.round((batteryPct.toDouble() / screenOnDrainPctPerHour) * 60.0)
                .toInt()
                .coerceIn(15, 20 * 60)
        }
        val capacityRatio = designCapacityMah.coerceIn(2500, 12000) / 5000.0
        return kotlin.math.round(batteryPct * 5.8 * capacityRatio)
            .toInt()
            .coerceIn(15, 20 * 60)
    }

    private fun recordAutopilotSave(context: Context, estMah: Int, logMessage: String) {
        try {
            val appCtx = context.applicationContext ?: context
            val prefs = appCtx.getSharedPreferences(PREFS_AUTOPILOT, Context.MODE_PRIVATE)
            val prevCount = prefs.getInt(KEY_AUTOPILOT_SAVES_COUNT, 0)
            val prevMah = prefs.getInt(KEY_ESTIMATED_SAVED_MAH, 0)
            prefs.edit()
                .putInt(KEY_AUTOPILOT_SAVES_COUNT, prevCount + 1)
                .putInt(KEY_ESTIMATED_SAVED_MAH, prevMah + estMah.coerceAtLeast(0))
                .apply()
            appendAutopilotLog(appCtx, logMessage)
        } catch (_: Throwable) {}
    }

    fun appendAutopilotLog(context: Context, message: String) {
        try {
            val appCtx = context.applicationContext ?: context
            val prefs = appCtx.getSharedPreferences(PREFS_AUTOPILOT, Context.MODE_PRIVATE)
            val raw = prefs.getString(KEY_RECENT_LOGS_JSON, "[]") ?: "[]"
            val arr = try { JSONArray(raw) } catch (_: Throwable) { JSONArray() }
            val stamp = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            val list = mutableListOf("[$stamp] $message")
            for (i in 0 until arr.length()) {
                val item = arr.optString(i)
                if (item.isNotBlank() && list.size < 8) list.add(item)
            }
            val nextArr = JSONArray().apply { list.forEach { put(it) } }
            prefs.edit().putString(KEY_RECENT_LOGS_JSON, nextArr.toString()).apply()
        } catch (_: Throwable) {}
    }

    private fun isNightHoursNow(): Boolean {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return hour >= 23 || hour < 6 || (hour == 6 && Calendar.getInstance().get(Calendar.MINUTE) <= 30)
    }

    /**
     * Gọi từ ACTION_SCREEN_OFF của MagicTuneKeepAliveService (0% polling thừa).
     * Đợi 45s nếu màn hình vẫn tắt -> đưa máy vào Deep Doze siêu tốc + đóng băng app xả ngầm vừa chạy,
     * đồng thời giữ nguyên 100% Trợ năng On-Demand (ngủ yên 0% CPU, thức tức thì khi mở màn & gọi).
     */
    fun onScreenOff(context: Context) {
        val appCtx = context.applicationContext ?: context
        pendingScreenOffJob?.cancel()
        val cfg = getConfig(appCtx)
        if (!cfg.screenOffDeepDozeEnabled && !cfg.nightUltraStandbyEnabled) {
            pendingScreenOffJob = null
            return
        }
        pendingScreenOffJob = autopilotScope.launch {
            try {
                val batt = BatteryInfoReader.read(appCtx, lightweight = true)
                recordBatteryCheckpoint(
                    context = appCtx,
                    batteryPct = batt.batteryPct,
                    isCharging = batt.isCharging,
                    isScreenOn = false,
                    tempC = batt.tempCelsius,
                    force = true,
                    isScreenEvent = true
                )

                if (batt.isCharging) return@launch

                // Đợi 45 giây để chắc chắn người dùng thật sự tắt màn hình, tránh chạy thừa khi chỉ tắt bật nhanh
                delay(45_000L)

                val pm = appCtx.getSystemService(Context.POWER_SERVICE) as? PowerManager
                if (pm?.isInteractive == true) return@launch
                if (MagicTuneBatteryWidgetProvider.isMagicLiveOrScrollTranslateRunning()) return@launch

                val isNight = isNightHoursNow() && cfg.nightUltraStandbyEnabled
                val shell = ShellEngine.getInstance(appCtx)
                if (shell.state.value.isAdbReady) {
                    val cmds = mutableListOf<String>()
                    cmds.addAll(buildMagicTuneAccessibilityShieldCommands(appCtx.packageName))
                    if (isNight) {
                        cmds.add("settings put secure doze_always_on 0 >/dev/null 2>&1 || true")
                        cmds.add("settings put global mobile_data_always_on 0 >/dev/null 2>&1 || true")
                        cmds.add("settings put global wifi_scan_always_enabled 0 >/dev/null 2>&1 || true")
                        cmds.add("settings put global ble_scan_always_enabled 0 >/dev/null 2>&1 || true")
                        cmds.add("dumpsys deviceidle force-idle deep >/dev/null 2>&1 || dumpsys deviceidle force-idle light >/dev/null 2>&1 || true")
                    } else if (cfg.screenOffDeepDozeEnabled) {
                        cmds.add("dumpsys deviceidle force-idle light >/dev/null 2>&1 || true")
                    }
                    shell.execute(cmds.joinToString(" ; "), isBackground = true)
                }

                // Đảm bảo Trợ năng On-Demand ngủ yên 0% CPU khi tắt màn hình mà không làm hỏng khả năng gọi lại
                MagicTuneCtsAccessibilityService.purgeFromSecureSettingsIfIdle(appCtx)

                if (isNight) {
                    recordAutopilotSave(
                        appCtx,
                        estMah = 45,
                        logMessage = "🌃 AI Chống Tụt Pin Qua Đêm đã yêu cầu Android vào Deep Doze; không ép dừng ứng dụng khác"
                    )
                } else {
                    recordAutopilotSave(
                        appCtx,
                        estMah = 18,
                        logMessage = "🌙 AI Ngủ Đông Tắt Màn đã yêu cầu Android vào Light Doze; không ép dừng ứng dụng khác"
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                Log.w(AUTOPILOT_TAG, "onScreenOff autopilot error: ${e.message}")
            }
        }
    }

    /**
     * Gọi từ ACTION_SCREEN_ON của MagicTuneKeepAliveService.
     * Hủy ngay delay ngủ đông và đánh thức nhẹ hệ thống để giao diện & cầu nối Trợ năng phản hồi 0ms!
     */
    fun onScreenOn(context: Context) {
        val appCtx = context.applicationContext ?: context
        pendingScreenOffJob?.cancel()
        pendingScreenOffJob = null
        val cfg = getConfig(appCtx)
        if (!cfg.screenOffDeepDozeEnabled && !cfg.nightUltraStandbyEnabled) return
        autopilotScope.launch {
            try {
                val batt = BatteryInfoReader.read(appCtx, lightweight = true)
                recordBatteryCheckpoint(
                    context = appCtx,
                    batteryPct = batt.batteryPct,
                    isCharging = batt.isCharging,
                    isScreenOn = true,
                    tempC = batt.tempCelsius,
                    force = true,
                    isScreenEvent = true,
                    chargeCounterUah = batt.chargeCounterUah
                )
                // Cập nhật tức thì Widget pin 3x2 & 2x2 ngay khi mở màn hình để hiển thị số đo Tắt màn chờ µAh mới nhất
                try {
                    MagicTuneBatteryWidgetProvider.notifyAllWidgetsFast(appCtx)
                    com.example.core.widget.MagicTuneSimpleBatteryWidgetProvider.notifyAllWidgets(appCtx)
                } catch (_: Throwable) {}
                if (cfg.screenOffDeepDozeEnabled || cfg.nightUltraStandbyEnabled) {
                    val shell = ShellEngine.getInstance(appCtx)
                    if (shell.state.value.isAdbReady) {
                        shell.execute("dumpsys deviceidle unforce >/dev/null 2>&1 || true", isBackground = true)
                    }
                }
            } catch (_: Throwable) {}
        }
    }

    /**
     * Gọi từ ACTION_BATTERY_CHANGED (đã được throttle 60s ở KeepAliveService -> 0% tốn pin).
     * Handles the explicitly enabled low-battery rule only. Thermal power reduction is user-triggered.
     */
    fun onBatteryStateSampled(
        context: Context,
        batteryPct: Int,
        isCharging: Boolean,
        tempC: Double,
        isScreenOn: Boolean
    ) {
        val appCtx = context.applicationContext ?: context
        autopilotScope.launch {
            try {
                val cfg = getConfig(appCtx)
                if (!cfg.lowBatterySurvivalEnabled) return@launch
                recordBatteryCheckpoint(
                    context = appCtx,
                    batteryPct = batteryPct,
                    isCharging = isCharging,
                    isScreenOn = isScreenOn,
                    tempC = tempC,
                    force = false
                )

                val nowElapsed = SystemClock.elapsedRealtime()
                val prefs = appCtx.getSharedPreferences(PREFS_AUTOPILOT, Context.MODE_PRIVATE)
                val wasAutoSurvival = prefs.getBoolean(KEY_AUTO_TRIGGERED_SURVIVAL, false)

                // Lá chắn 1: Phòng thủ pin yếu <= 20%
                if (cfg.lowBatterySurvivalEnabled && (nowElapsed - lastLowBattActionElapsedMs >= 180_000L)) {
                    if (!isCharging && batteryPct in 1..20 && !wasAutoSurvival) {
                        lastLowBattActionElapsedMs = nowElapsed
                        prefs.edit().putBoolean(KEY_AUTO_TRIGGERED_SURVIVAL, true).apply()
                        AiBatteryDoctorEngine.activateUltraPowerSaverPreset(
                            context = appCtx,
                            profile = AiUltraPowerProfile.SURVIVAL_MAX,
                            drainReport = BackgroundDrainInspector.peekRamCachedReportOnly()
                        )
                        recordAutopilotSave(
                            appCtx,
                            estMah = 90,
                            logMessage = "🪫 Pin còn $batteryPct%: AI tự động bật chế độ Sinh Tồn Pin Trâu (Giữ 100% Trợ năng & cuộc gọi)"
                        )
                    } else if (wasAutoSurvival && (isCharging || batteryPct >= 30)) {
                        lastLowBattActionElapsedMs = nowElapsed
                        prefs.edit().putBoolean(KEY_AUTO_TRIGGERED_SURVIVAL, false).apply()
                        AiBatteryDoctorEngine.activateUltraPowerSaverPreset(
                            context = appCtx,
                            profile = AiUltraPowerProfile.BALANCED_24_7,
                            drainReport = BackgroundDrainInspector.peekRamCachedReportOnly()
                        )
                        appendAutopilotLog(
                            appCtx,
                            "⚡ Pin đã hồi ($batteryPct%): AI tự động chuyển về chế độ Tiết Kiệm 24/7 mượt mà"
                        )
                    }
                }

            } catch (_: Throwable) {}
        }
    }
}
