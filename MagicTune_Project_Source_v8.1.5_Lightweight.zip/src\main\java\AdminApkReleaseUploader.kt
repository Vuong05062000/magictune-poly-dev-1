package com.example.core.installer

import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.coroutines.coroutineContext

/**
 * Công cụ tải tệp APK bản mới nhất từ máy Admin lên đám mây (Cloud OTA Publisher):
 * - Chọn tệp .apk an toàn qua Android SAF (OpenDocument — 0 quyền bộ nhớ) hoặc lấy trực tiếp bản APK đang cài.
 * - Tự động xác thực chữ ký ZIP/APK & đọc versionName, versionCode, packageName khớp ứng dụng.
 * - Luồng tải lên 2 tầng dự phòng tự động (Zero-Fail Cascade):
 *   1) Ưu tiên Firebase Storage của chính dự án (`phn-mm-ha-n.firebasestorage.app`) kèm Firebase Auth Bearer Token.
 *   2) Nếu Firebase Storage chưa kích hoạt hoặc bị giới hạn rule -> Tự động chuyển mượt sang Catbox Permanent Direct CDN (hỗ trợ tối đa 200MB, link tải thẳng HTTPS).
 */
object AdminApkReleaseUploader {

    private const val FIREBASE_STORAGE_BUCKET = "phn-mm-ha-n.firebasestorage.app"
    private const val MAX_APK_SIZE_BYTES = 195L * 1024L * 1024L // 195 MB

    data class InspectedLocalApk(
        val file: File,
        val fileName: String,
        val packageName: String,
        val versionName: String,
        val versionCode: Long,
        val sizeBytes: Long,
        val isTempStagingFile: Boolean
    )

    data class UploadProgress(
        val uploadedBytes: Long,
        val totalBytes: Long,
        val percent: Int,
        val speedKbps: Int,
        val stageLabel: String
    )

    sealed class UploadResult {
        data class Success(
            val downloadUrl: String,
            val hostLabel: String,
            val apkInfo: InspectedLocalApk
        ) : UploadResult()

        data class Error(val message: String) : UploadResult()
    }

    private fun queryDisplayName(context: Context, uri: Uri): String {
        return try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) cursor.getString(idx) else null
                } else null
            }
        } catch (_: Throwable) {
            null
        }?.takeIf { it.isNotBlank() } ?: "MagicTune_Release.apk"
    }

    suspend fun prepareApkFromUri(context: Context, uri: Uri): Result<InspectedLocalApk> = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext ?: context
        val stagingDir = File(appCtx.cacheDir, "admin_apk_upload").apply { if (!exists()) mkdirs() }
        val stagingFile = File(stagingDir, "staging_release_${System.currentTimeMillis()}.apk")
        try {
            // Dọn các tệp tạm cũ
            stagingDir.listFiles()?.forEach { old ->
                if (old.isFile && old.name != stagingFile.name) {
                    try { old.delete() } catch (_: Throwable) {}
                }
            }

            val displayName = queryDisplayName(appCtx, uri)
            val input = appCtx.contentResolver.openInputStream(uri)
                ?: return@withContext Result.failure(IllegalStateException("Không thể đọc tệp APK đã chọn."))

            var totalCopied = 0L
            var magicChecked = false
            input.use { src ->
                FileOutputStream(stagingFile).use { dst ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        coroutineContext.ensureActive()
                        val n = src.read(buf)
                        if (n == -1) break
                        if (!magicChecked && n >= 4) {
                            magicChecked = true
                            if (buf[0] != 0x50.toByte() || buf[1] != 0x4B.toByte()) {
                                return@withContext Result.failure(
                                    IllegalArgumentException("Tệp vừa chọn không phải định dạng tệp cài đặt Android (.apk).")
                                )
                            }
                        }
                        dst.write(buf, 0, n)
                        totalCopied += n
                        if (totalCopied > MAX_APK_SIZE_BYTES) {
                            return@withContext Result.failure(
                                IllegalArgumentException("Tệp APK vượt quá giới hạn tối đa 195 MB.")
                            )
                        }
                    }
                    dst.flush()
                }
            }

            if (totalCopied < 512 * 1024L) {
                try { stagingFile.delete() } catch (_: Throwable) {}
                return@withContext Result.failure(
                    IllegalArgumentException("Tệp quá nhỏ (${totalCopied / 1024} KB), không phải gói APK hợp lệ.")
                )
            }

            val inspected = inspectApkFile(appCtx, stagingFile, displayName, isTempStagingFile = true)
                ?: run {
                    try { stagingFile.delete() } catch (_: Throwable) {}
                    return@withContext Result.failure(
                        IllegalArgumentException("Không thể đọc thông tin gói từ tệp APK. Tệp có thể bị lỗi hoặc chưa tải xong.")
                    )
                }

            if (inspected.packageName != appCtx.packageName) {
                try { stagingFile.delete() } catch (_: Throwable) {}
                return@withContext Result.failure(
                    IllegalArgumentException(
                        "Tệp APK khác mã gói ứng dụng (${inspected.packageName} ≠ ${appCtx.packageName}). Hãy chọn đúng tệp MagicTune Tool."
                    )
                )
            }

            Result.success(inspected)
        } catch (e: CancellationException) {
            try { stagingFile.delete() } catch (_: Throwable) {}
            throw e
        } catch (e: Throwable) {
            try { stagingFile.delete() } catch (_: Throwable) {}
            Result.failure(e)
        }
    }

    suspend fun prepareCurrentInstalledApk(context: Context): Result<InspectedLocalApk> = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext ?: context
        try {
            val sourcePath = appCtx.applicationInfo.sourceDir
            if (sourcePath.isNullOrBlank()) {
                return@withContext Result.failure(IllegalStateException("Không tìm thấy tệp APK đang cài trên thiết bị."))
            }
            val sourceFile = File(sourcePath)
            if (!sourceFile.exists() || !sourceFile.canRead() || sourceFile.length() < 512 * 1024L) {
                return@withContext Result.failure(IllegalStateException("Không thể truy cập tệp APK gốc của ứng dụng."))
            }
            val inspected = inspectApkFile(
                context = appCtx,
                apkFile = sourceFile,
                fileName = "MagicTune_Tool_Installed.apk",
                isTempStagingFile = false
            ) ?: return@withContext Result.failure(IllegalStateException("Không thể đọc thông tin phiên bản hiện tại."))
            Result.success(
                inspected.copy(
                    fileName = "MagicTune_Tool_v${inspected.versionName}_b${inspected.versionCode}.apk"
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            Result.failure(e)
        }
    }

    private fun inspectApkFile(
        context: Context,
        apkFile: File,
        fileName: String,
        isTempStagingFile: Boolean
    ): InspectedLocalApk? {
        return try {
            val pm = context.packageManager
            val pkgInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageArchiveInfo(
                    apkFile.absolutePath,
                    PackageManager.PackageInfoFlags.of(0L)
                )
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageArchiveInfo(apkFile.absolutePath, 0)
            } ?: return null

            val vCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                pkgInfo.longVersionCode
            } else {
                @Suppress("DEPRECATION")
                pkgInfo.versionCode.toLong()
            }
            val vName = pkgInfo.versionName.orEmpty().ifBlank { "Mới" }
            InspectedLocalApk(
                file = apkFile,
                fileName = fileName,
                packageName = pkgInfo.packageName.orEmpty(),
                versionName = vName,
                versionCode = vCode,
                sizeBytes = apkFile.length(),
                isTempStagingFile = isTempStagingFile
            )
        } catch (_: Throwable) {
            null
        }
    }

    suspend fun uploadApkToCloud(
        context: Context,
        apk: InspectedLocalApk,
        onProgress: (UploadProgress) -> Unit
    ): UploadResult = withContext(Dispatchers.IO) {
        try {
            // Tầng 1: Ưu tiên tải thẳng lên Firebase Storage của dự án (nếu Storage bucket đã kích hoạt & cho phép ghi)
            val fbError: String? = try {
                val fbUrl = uploadToFirebaseStorage(apk, onProgress)
                if (!fbUrl.isNullOrBlank()) {
                    return@withContext UploadResult.Success(
                        downloadUrl = fbUrl,
                        hostLabel = "Firebase Storage",
                        apkInfo = apk
                    )
                }
                null
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                e.message
            }

            // Tầng 2: Tự động chuyển mượt sang Catbox Permanent Direct CDN (link tải thẳng HTTPS ổn định, hỗ trợ tới 200MB)
            val catboxError: String? = try {
                val cdnUrl = uploadToCatboxCdn(apk, onProgress)
                if (!cdnUrl.isNullOrBlank()) {
                    return@withContext UploadResult.Success(
                        downloadUrl = cdnUrl,
                        hostLabel = "Cloud CDN Trực Tiếp",
                        apkInfo = apk
                    )
                }
                null
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                e.message
            }

            val detail = listOfNotNull(
                fbError?.let { "Firebase Storage: $it" },
                catboxError?.let { "Cloud CDN: $it" }
            ).joinToString(" | ").ifBlank { "Không thể kết nối máy chủ lưu trữ." }

            UploadResult.Error("Tải tệp APK lên mây thất bại ($detail). Vui lòng kiểm tra mạng hoặc dán link trực tiếp.")
        } finally {
            if (apk.isTempStagingFile) {
                try { apk.file.delete() } catch (_: Throwable) {}
            }
        }
    }

    private suspend fun uploadToFirebaseStorage(
        apk: InspectedLocalApk,
        onProgress: (UploadProgress) -> Unit
    ): String? {
        val idToken = try {
            FirebaseAuth.getInstance().currentUser?.getIdToken(false)?.await()?.token
        } catch (_: Throwable) {
            null
        }
        val safeVer = apk.versionName.replace(Regex("[^a-zA-Z0-9._-]"), "_")
        val objectName = "apk_releases/MagicTune_v${safeVer}_b${apk.versionCode}_${System.currentTimeMillis()}.apk"
        val encodedName = URLEncoder.encode(objectName, "UTF-8")
        val endpoint = "https://firebasestorage.googleapis.com/v0/b/$FIREBASE_STORAGE_BUCKET/o?uploadType=media&name=$encodedName"

        var conn: HttpURLConnection? = null
        try {
            onProgress(UploadProgress(0L, apk.sizeBytes, 0, 0, "Đang kết nối Firebase Storage..."))
            conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                doInput = true
                connectTimeout = 15_000
                readTimeout = 60_000
                setFixedLengthStreamingMode(apk.sizeBytes)
                setRequestProperty("Content-Type", "application/vnd.android.package-archive")
                if (!idToken.isNullOrBlank()) {
                    setRequestProperty("Authorization", "Bearer $idToken")
                }
            }

            streamFileWithProgress(
                file = apk.file,
                output = conn.outputStream,
                totalBytes = apk.sizeBytes,
                stageLabel = "Đang tải lên Firebase Storage...",
                onProgress = onProgress
            )

            val code = conn.responseCode
            val body = try {
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                stream?.bufferedReader()?.readText().orEmpty()
            } catch (_: Throwable) {
                ""
            }

            if (code !in 200..299) {
                throw IllegalStateException("HTTP $code")
            }

            val json = JSONObject(body)
            val returnedName = json.optString("name", objectName)
            val tokensRaw = json.optString("downloadTokens", "")
            val firstToken = tokensRaw.split(",").firstOrNull { it.isNotBlank() }?.trim().orEmpty()
            val encodedReturned = URLEncoder.encode(returnedName, "UTF-8")
            val finalUrl = if (firstToken.isNotBlank()) {
                "https://firebasestorage.googleapis.com/v0/b/$FIREBASE_STORAGE_BUCKET/o/$encodedReturned?alt=media&token=$firstToken"
            } else {
                "https://firebasestorage.googleapis.com/v0/b/$FIREBASE_STORAGE_BUCKET/o/$encodedReturned?alt=media"
            }
            onProgress(UploadProgress(apk.sizeBytes, apk.sizeBytes, 100, 0, "Đã hoàn tất tải lên Firebase Storage!"))
            return finalUrl
        } finally {
            try { conn?.disconnect() } catch (_: Throwable) {}
        }
    }

    private suspend fun uploadToCatboxCdn(
        apk: InspectedLocalApk,
        onProgress: (UploadProgress) -> Unit
    ): String? {
        val boundary = "----MagicTuneApkBoundary${System.currentTimeMillis()}"
        val safeFileName = "MagicTune_v${apk.versionName.replace(Regex("[^a-zA-Z0-9._-]"), "_")}_b${apk.versionCode}.apk"
        val headerPart = buildString {
            append("--").append(boundary).append("\r\n")
            append("Content-Disposition: form-data; name=\"reqtype\"\r\n\r\n")
            append("fileupload\r\n")
            append("--").append(boundary).append("\r\n")
            append("Content-Disposition: form-data; name=\"fileToUpload\"; filename=\"").append(safeFileName).append("\"\r\n")
            append("Content-Type: application/vnd.android.package-archive\r\n\r\n")
        }.toByteArray(Charsets.UTF_8)
        val footerPart = "\r\n--$boundary--\r\n".toByteArray(Charsets.UTF_8)
        val totalContentLength = headerPart.size.toLong() + apk.sizeBytes + footerPart.size.toLong()

        var conn: HttpURLConnection? = null
        try {
            onProgress(UploadProgress(0L, apk.sizeBytes, 0, 0, "Đang tải lên Cloud CDN trực tiếp..."))
            conn = (URL("https://catbox.moe/user/api.php").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                doInput = true
                connectTimeout = 20_000
                readTimeout = 90_000
                setFixedLengthStreamingMode(totalContentLength)
                setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
                setRequestProperty("User-Agent", "MagicTuneTool/7.3 (Android)")
            }

            conn.outputStream.use { out ->
                out.write(headerPart)
                streamFileWithProgress(
                    file = apk.file,
                    output = out,
                    totalBytes = apk.sizeBytes,
                    stageLabel = "Đang tải APK lên Cloud CDN...",
                    onProgress = onProgress,
                    closeStream = false
                )
                out.write(footerPart)
                out.flush()
            }

            val code = conn.responseCode
            val body = try {
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                stream?.bufferedReader()?.readText()?.trim().orEmpty()
            } catch (_: Throwable) {
                ""
            }

            if (code !in 200..299 || !body.startsWith("https://")) {
                throw IllegalStateException("HTTP $code ${body.take(80)}")
            }
            onProgress(UploadProgress(apk.sizeBytes, apk.sizeBytes, 100, 0, "Đã hoàn tất tải lên Cloud CDN!"))
            return body
        } finally {
            try { conn?.disconnect() } catch (_: Throwable) {}
        }
    }

    private suspend fun streamFileWithProgress(
        file: File,
        output: java.io.OutputStream,
        totalBytes: Long,
        stageLabel: String,
        onProgress: (UploadProgress) -> Unit,
        closeStream: Boolean = true
    ) {
        val buf = ByteArray(64 * 1024)
        var uploaded = 0L
        var lastNotifyMs = 0L
        var lastNotifyBytes = 0L
        val startedMs = System.currentTimeMillis()
        try {
            BufferedInputStream(FileInputStream(file), 64 * 1024).use { input ->
                while (true) {
                    coroutineContext.ensureActive()
                    val n = input.read(buf)
                    if (n == -1) break
                    output.write(buf, 0, n)
                    uploaded += n
                    val nowMs = System.currentTimeMillis()
                    if (nowMs - lastNotifyMs >= 180L || uploaded >= totalBytes) {
                        val dtSec = ((nowMs - lastNotifyMs).coerceAtLeast(1L)) / 1000.0
                        val speedKbps = if (lastNotifyMs == 0L) {
                            val totalSec = ((nowMs - startedMs).coerceAtLeast(1L)) / 1000.0
                            ((uploaded / 1024.0) / totalSec).toInt().coerceAtLeast(1)
                        } else {
                            (((uploaded - lastNotifyBytes) / 1024.0) / dtSec).toInt().coerceAtLeast(1)
                        }
                        val pct = if (totalBytes > 0L) {
                            ((uploaded * 100L) / totalBytes).toInt().coerceIn(0, 99)
                        } else 0
                        onProgress(UploadProgress(uploaded, totalBytes, pct, speedKbps, stageLabel))
                        lastNotifyMs = nowMs
                        lastNotifyBytes = uploaded
                    }
                }
                output.flush()
            }
        } finally {
            if (closeStream) {
                try { output.close() } catch (_: Throwable) {}
            }
        }
    }
}
