import os
import re

src_dir = r"C:\Users\Administrator\.gemini\antigravity\scratch\MagicTune\src\main\java"
target_files = [
    "TuneScreen.kt",
    "SetupScreen.kt",
    "NotificationScreen.kt",
    "UniversalOemFixScreen.kt",
    "BackgroundRunningAppsDialog.kt",
    "ShizukuWlanScreen.kt"
]

for fname in target_files:
    fpath = os.path.join(src_dir, fname)
    if not os.path.exists(fpath):
        continue
    with open(fpath, "r", encoding="utf-8") as f:
        content = f.read()

    # 1. Add imports if needed
    if "import androidx.compose.foundation.layout.IntrinsicSize" not in content:
        if "import androidx.compose.foundation.layout.Row" in content:
            content = content.replace(
                "import androidx.compose.foundation.layout.Row",
                "import androidx.compose.foundation.layout.IntrinsicSize\nimport androidx.compose.foundation.layout.Row\nimport androidx.compose.foundation.layout.fillMaxHeight"
            )
        elif "import androidx.compose.foundation.layout.*" in content:
            pass # already imported via wildcard
        else:
            content = re.sub(
                r"(package [^\n]+\n)",
                r"\1\nimport androidx.compose.foundation.layout.IntrinsicSize\nimport androidx.compose.foundation.layout.fillMaxHeight\n",
                content,
                count=1
            )

    lines = content.split("\n")
    new_lines = []
    i = 0
    modified_rows = 0
    modified_buttons = 0

    while i < len(lines):
        line = lines[i]
        # Check if line starts a Row that has multiple buttons
        if re.search(r"\bRow\s*\(", line):
            # lookahead 40 lines
            chunk = "\n".join(lines[i:min(len(lines), i+40)])
            btns = re.findall(r"\b(Button|OutlinedButton)\s*\(", chunk)
            if len(btns) >= 2:
                # Find end of Row parameters
                row_end = i
                while row_end < min(len(lines), i+8) and ") {" not in lines[row_end] and "){" not in lines[row_end]:
                    row_end += 1
                row_block = "\n".join(lines[i:row_end+1])
                if "IntrinsicSize" not in row_block:
                    if "Modifier.fillMaxWidth()" in row_block:
                        row_block = row_block.replace("Modifier.fillMaxWidth()", "Modifier.fillMaxWidth().height(IntrinsicSize.Min)")
                        modified_rows += 1
                    elif "Modifier." in row_block:
                        row_block = re.sub(r"(modifier\s*=\s*Modifier\.[a-zA-Z0-9_.()]+)", r"\1.height(IntrinsicSize.Min)", row_block, count=1)
                        modified_rows += 1
                    else:
                        row_block = re.sub(r"(Row\s*\()", r"\1modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min), ", row_block, count=1)
                        modified_rows += 1
                    for rline in row_block.split("\n"):
                        new_lines.append(rline)
                    i = row_end + 1
                    continue

        # Check if line has Button modifier with weight but not fillMaxHeight
        if ".weight(" in line and ".fillMaxHeight()" not in line:
            line = line.replace(".weight(", ".fillMaxHeight().weight(")
            modified_buttons += 1

        # Normalize excessively high button heights to 36dp
        if "heightIn(min = 48.dp)" in line:
            line = line.replace("heightIn(min = 48.dp)", "defaultMinSize(minHeight = 36.dp)")
        elif "heightIn(min = 46.dp)" in line:
            line = line.replace("heightIn(min = 46.dp)", "defaultMinSize(minHeight = 36.dp)")
        elif "heightIn(min = 44.dp)" in line:
            line = line.replace("heightIn(min = 44.dp)", "defaultMinSize(minHeight = 36.dp)")
        elif "heightIn(min = 42.dp)" in line:
            line = line.replace("heightIn(min = 42.dp)", "defaultMinSize(minHeight = 36.dp)")
        elif "heightIn(min = 40.dp)" in line:
            line = line.replace("heightIn(min = 40.dp)", "defaultMinSize(minHeight = 36.dp)")

        new_lines.append(line)
        i += 1

    updated_content = "\n".join(new_lines)
    with open(fpath, "w", encoding="utf-8") as f:
        f.write(updated_content)
    print(f"{fname}: updated {modified_rows} rows, {modified_buttons} buttons")
