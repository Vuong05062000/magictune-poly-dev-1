package com.example.core.installer

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import com.example.core.shell.ShellEngine
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.coroutines.coroutineContext

/**
 * Trình Cập Nhật Ứng Dụng Trực Tiếp Trong App (InAppApkUpdater):
 * - Hỗ trợ tải trực tiếp từ Link APK (GitHub Releases, Cloudflare R2, Server riêng, Dropbox)
 *   và tự động chuyển đổi Link File Google Drive (`/file/d/<ID>/view` -> tải trực tiếp không qua trình duyệt).
 * - Xác thực chữ ký cấu trúc APK (`PK\x03\x04` + `PackageManager.getPackageArchiveInfo`) trước khi cài.
 * - Hỗ trợ cài đặt 2 chế độ:
 *   1) Cài siêu tốc qua WLAN ADB / Shizuku (vượt qua chặn "App verification failed" trên Honor MagicOS nội địa).
 *   2) Mở trình cài đặt hệ thống qua FileProvider (tự kiểm tra quyền `REQUEST_INSTALL_PACKAGES`).
 */
object InAppApkUpdater {

    data class DownloadProgress(
        val downloadedBytes: Long,
        val totalBytes: Long,
        val percent: Int,
        val speedKbps: Int
    )

    data class DownloadedApkInfo(
        val file: File,
        val packageName: String,
        val versionName: String,
        val versionCode: Long,
        val sizeBytes: Long
    )

    sealed class DownloadResult {
        data class Success(val info: DownloadedApkInfo) : DownloadResult()
        data class FolderLinkOnly(val url: String, val message: String) : DownloadResult()
        data class Error(val message: String) : DownloadResult()
    }

    sealed class InstallActionResult {
        data class InstalledViaAdb(val message: String) : InstallActionResult()
        data class OpenedSystemInstaller(val message: String) : InstallActionResult()
        data class NeedsUnknownSourcesPermission(val message: String) : InstallActionResult()
        data class Error(val message: String) : InstallActionResult()
    }

    fun isDriveFolderLink(url: String): Boolean {
        val lower = url.trim().lowercase()
        return lower.contains("drive.google.com/drive/folders/") ||
            lower.contains("drive.google.com/drive/u/") && lower.contains("/folders/")
    }

    fun isDirectDownloadableUrl(url: String): Boolean {
        val clean = url.trim()
        if (!clean.startsWith("http://") && !clean.startsWith("https://")) return false
        if (isDriveFolderLink(clean)) return false
        return true
    }

    /**
     * Tự động chuẩn hóa URL chia sẻ (Google Drive file, Dropbox, GitHub blob) thành URL tải thẳng tệp APK.
     */
    fun resolveDirectApkUrl(rawUrl: String): String {
        val trimmed = rawUrl.trim()
        // 1. Google Drive File: https://drive.google.com/file/d/<ID>/view...
        val driveFileMatch = Regex("""drive\.google\.com/file/d/([a-zA-Z0-9_-]+)""").find(trimmed)
        if (driveFileMatch != null) {
            val fileId = driveFileMatch.groupValues[1]
            return "https://drive.usercontent.google.com/download?id=$fileId&export=download&confirm=t"
        }
        // 2. Google Drive open/uc: https://drive.google.com/open?id=<ID> hoặc uc?id=<ID>
        val driveIdMatch = Regex("""drive\.google\.com/(?:open|uc)\?[^#]*\bid=([a-zA-Z0-9_-]+)""").find(trimmed)
        if (driveIdMatch != null) {
            val fileId = driveIdMatch.groupValues[1]
            return "https://drive.usercontent.google.com/download?id=$fileId&export=download&confirm=t"
        }
        // 3. Dropbox share link -> dl=1
        if (trimmed.contains("dropbox.com", ignoreCase = true)) {
            return when {
                trimmed.contains("dl=0") -> trimmed.replace("dl=0", "dl=1")
                trimmed.contains("dl=1") -> trimmed
                trimmed.contains("?") -> "$trimmed&dl=1"
                else -> "$trimmed?dl=1"
            }
        }
        // 4. GitHub blob -> raw
        if (trimmed.contains("github.com/", ignoreCase = true) && trimmed.contains("/blob/")) {
            return trimmed.replace("github.com/", "raw.githubusercontent.com/").replace("/blob/", "/")
        }
        return trimmed
    }

    private const val PREF_NAME = "magictune_in_app_updater_prefs"
    private const val KEY_CACHED_APK_SOURCE_URL = "cached_apk_source_url"

    private fun getUpdateApkFile(context: Context): File {
        val baseDir = context.externalCacheDir ?: context.cacheDir
        val updateDir = File(baseDir, "in_app_update").apply {
            if (!exists()) mkdirs()
        }
        return File(updateDir, "MagicTune_Update_Latest.apk")
    }

    fun getExistingDownloadedApk(context: Context, expectedUrl: String = ""): DownloadedApkInfo? {
        val file = getUpdateApkFile(context)
        if (!file.exists() || file.length() < 512 * 1024L) return null
        val cleanExpected = expectedUrl.trim()
        if (cleanExpected.isNotBlank()) {
            val cachedUrl = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .getString(KEY_CACHED_APK_SOURCE_URL, "")?.trim().orEmpty()
            if (cachedUrl != cleanExpected) {
                try { file.delete() } catch (_: Throwable) {}
                return null
            }
        }
        return inspectApkFile(context, file)
    }

    fun clearDownloadedApk(context: Context) {
        try {
            val f = getUpdateApkFile(context)
            if (f.exists()) f.delete()
            context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .edit()
                .remove(KEY_CACHED_APK_SOURCE_URL)
                .apply()
        } catch (_: Throwable) {}
    }

    fun canRequestPackageInstalls(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                context.packageManager.canRequestPackageInstalls()
            } catch (_: Throwable) {
                true
            }
        } else {
            true
        }
    }

    fun openUnknownAppSourcesSettings(context: Context) {
        try {
            val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Intent(
                    Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:${context.packageName}")
                )
            } else {
                Intent(Settings.ACTION_SECURITY_SETTINGS)
            }.apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Throwable) {}
    }

    suspend fun downloadApk(
        context: Context,
        rawUrl: String,
        onProgress: (DownloadProgress) -> Unit
    ): DownloadResult = withContext(Dispatchers.IO) {
        val cleanUrl = rawUrl.trim()
        if (cleanUrl.isBlank()) {
            return@withContext DownloadResult.Error("Chưa cấu hình đường dẫn tải bản cập nhật.")
        }
        if (isDriveFolderLink(cleanUrl)) {
            return@withContext DownloadResult.FolderLinkOnly(
                url = cleanUrl,
                message = "Link hiện tại là thư mục Google Drive (không phải link tệp APK trực tiếp). Bạn có thể mở thư mục để tải hoặc dán link tệp APK trực tiếp (GitHub / Drive file)."
            )
        }

        val targetUrl = resolveDirectApkUrl(cleanUrl)
        val appCtx = context.applicationContext ?: context
        val destFile = getUpdateApkFile(appCtx)
        val partFile = File(destFile.parentFile, "MagicTune_Update_Downloading.part")
        if (partFile.exists()) {
            try { partFile.delete() } catch (_: Throwable) {}
        }

        var conn: HttpURLConnection? = null
        try {
            var currentUrl = targetUrl
            var redirectCount = 0
            while (redirectCount < 6) {
                coroutineContext.ensureActive()
                val connection = (URL(currentUrl).openConnection() as HttpURLConnection).apply {
                    instanceFollowRedirects = false
                    connectTimeout = 15_000
                    readTimeout = 25_000
                    requestMethod = "GET"
                    setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 15) MagicTuneUpdater/7.3")
                    setRequestProperty("Accept", "*/*")
                }
                val code = connection.responseCode
                if (code in 300..399) {
                    val location = connection.getHeaderField("Location")
                    connection.disconnect()
                    if (location.isNullOrBlank()) {
                        return@withContext DownloadResult.Error("Máy chủ chuyển hướng không hợp lệ (HTTP $code).")
                    }
                    currentUrl = URL(URL(currentUrl), location).toString()
                    redirectCount++
                    continue
                }
                conn = connection
                break
            }

            val activeConn = conn ?: return@withContext DownloadResult.Error("Quá nhiều lần chuyển hướng khi tải APK.")
            val code = activeConn.responseCode
            if (code !in 200..299) {
                return@withContext DownloadResult.Error("Không thể tải tệp APK (Mã máy chủ HTTP $code).")
            }

            val contentType = activeConn.contentType.orEmpty().lowercase()
            if (contentType.contains("text/html")) {
                return@withContext DownloadResult.Error(
                    "Đường dẫn trả về trang web thay vì tệp APK trực tiếp. Hãy dùng link tệp APK trực tiếp (GitHub Releases hoặc Google Drive chia sẻ công khai tệp APK)."
                )
            }

            val totalBytes = activeConn.contentLengthLong.coerceAtLeast(-1L)
            val buffer = ByteArray(32 * 1024)
            var downloaded = 0L
            var lastNotifyMs = 0L
            var lastNotifyBytes = 0L
            val startedMs = System.currentTimeMillis()

            activeConn.inputStream.use { input ->
                FileOutputStream(partFile).use { output ->
                    var firstChunkChecked = false
                    while (true) {
                        coroutineContext.ensureActive()
                        val read = input.read(buffer)
                        if (read == -1) break
                        if (!firstChunkChecked && read >= 4) {
                            firstChunkChecked = true
                            // Kiểm tra chữ ký đầu file ZIP/APK: PK (0x50 0x4B)
                            if (buffer[0] != 0x50.toByte() || buffer[1] != 0x4B.toByte()) {
                                return@withContext DownloadResult.Error(
                                    "Tệp tải về không đúng định dạng APK (có thể link yêu cầu đăng nhập hoặc bị giới hạn chia sẻ)."
                                )
                            }
                        }
                        output.write(buffer, 0, read)
                        downloaded += read
                        val nowMs = System.currentTimeMillis()
                        if (nowMs - lastNotifyMs >= 160L) {
                            val dtSec = ((nowMs - lastNotifyMs).coerceAtLeast(1L)) / 1000.0
                            val speedKbps = if (lastNotifyMs == 0L) {
                                val totalSec = ((nowMs - startedMs).coerceAtLeast(1L)) / 1000.0
                                ((downloaded / 1024.0) / totalSec).toInt().coerceAtLeast(1)
                            } else {
                                (((downloaded - lastNotifyBytes) / 1024.0) / dtSec).toInt().coerceAtLeast(1)
                            }
                            val pct = if (totalBytes > 0L) {
                                ((downloaded * 100L) / totalBytes).toInt().coerceIn(0, 100)
                            } else -1
                            onProgress(DownloadProgress(downloaded, totalBytes, pct, speedKbps))
                            lastNotifyMs = nowMs
                            lastNotifyBytes = downloaded
                        }
                    }
                    output.flush()
                }
            }

            if (downloaded < 512 * 1024L) {
                try { partFile.delete() } catch (_: Throwable) {}
                return@withContext DownloadResult.Error("Tệp tải về quá nhỏ (${downloaded / 1024}KB), không phải gói cài đặt hợp lệ.")
            }

            if (destFile.exists()) {
                try { destFile.delete() } catch (_: Throwable) {}
            }
            if (!partFile.renameTo(destFile)) {
                partFile.copyTo(destFile, overwrite = true)
                try { partFile.delete() } catch (_: Throwable) {}
            }

            onProgress(DownloadProgress(downloaded, if (totalBytes > 0L) totalBytes else downloaded, 100, 0))

            val inspected = inspectApkFile(appCtx, destFile)
                ?: return@withContext DownloadResult.Error("Tệp APK tải về bị lỗi cấu trúc hoặc chưa hoàn chỉnh. Vui lòng thử tải lại.")

            if (inspected.packageName.isNotBlank() && inspected.packageName != appCtx.packageName) {
                try { destFile.delete() } catch (_: Throwable) {}
                return@withContext DownloadResult.Error(
                    "Tệp APK không trùng mã gói ứng dụng (${inspected.packageName} != ${appCtx.packageName})."
                )
            }

            appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_CACHED_APK_SOURCE_URL, cleanUrl)
                .apply()

            DownloadResult.Success(inspected)
        } catch (e: CancellationException) {
            try { partFile.delete() } catch (_: Throwable) {}
            throw e
        } catch (e: Throwable) {
            try { partFile.delete() } catch (_: Throwable) {}
            DownloadResult.Error("Lỗi tải bản cập nhật: ${e.message ?: "Không có kết nối mạng"}")
        } finally {
            try { conn?.disconnect() } catch (_: Throwable) {}
        }
    }

    private fun inspectApkFile(context: Context, apkFile: File): DownloadedApkInfo? {
        return try {
            val pm = context.packageManager
            val pkgInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageArchiveInfo(
                    apkFile.absolutePath,
                    android.content.pm.PackageManager.PackageInfoFlags.of(0L)
                )
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageArchiveInfo(apkFile.absolutePath, 0)
            } ?: return null

            val vCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                pkgInfo.longVersionCode
            } else {
                @Suppress("DEPRECATION")
                pkgInfo.versionCode.toLong()
            }
            DownloadedApkInfo(
                file = apkFile,
                packageName = pkgInfo.packageName.orEmpty(),
                versionName = pkgInfo.versionName.orEmpty().ifBlank { "Mới" },
                versionCode = vCode,
                sizeBytes = apkFile.length()
            )
        } catch (_: Throwable) {
            null
        }
    }

    /**
     * Tiến hành cài đặt tệp APK đã tải về:
     * - Nếu `preferAdbIfReady = true` và đang kết nối WLAN ADB / Shizuku -> Cài ngầm trực tiếp (vượt qua lỗi chặn Honor MagicOS!).
     * - Ngược lại -> Mở bộ cài đặt Android chuẩn qua FileProvider (tự kiểm tra quyền nguồn không xác định).
     */
    suspend fun installDownloadedApk(
        context: Context,
        apkFile: File,
        preferAdbIfReady: Boolean = true
    ): InstallActionResult = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext ?: context
        if (!apkFile.exists() || apkFile.length() < 512 * 1024L) {
            return@withContext InstallActionResult.Error("Không tìm thấy tệp APK đã tải. Vui lòng tải lại.")
        }

        if (preferAdbIfReady) {
            val shell = ShellEngine.getInstance(appCtx)
            if (shell.state.value.isAdbReady) {
                val apkPath = apkFile.absolutePath
                val size = apkFile.length()
                val cmd = "pm install --bypass-low-target-sdk-block -r -t -d -g '$apkPath' 2>/dev/null || " +
                    "pm install -r -t -d -g '$apkPath' 2>/dev/null || " +
                    "cat '$apkPath' | pm install -r -t -d -g -S $size"
                val res = shell.execute(cmd)
                val out = (res.output + " " + res.error).trim()
                if (out.contains("Success", ignoreCase = true)) {
                    return@withContext InstallActionResult.InstalledViaAdb("✅ Đã cập nhật thành công qua ADB / Shizuku!")
                }
            }
        }

        if (!canRequestPackageInstalls(appCtx)) {
            return@withContext InstallActionResult.NeedsUnknownSourcesPermission(
                "Cần bật quyền 'Cài đặt ứng dụng không xác định' cho MagicTune Tool để cài bản cập nhật trực tiếp."
            )
        }

        try {
            val authority = "${appCtx.packageName}.fileprovider"
            val contentUri = FileProvider.getUriForFile(appCtx, authority, apkFile)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(contentUri, "application/vnd.android.package-archive")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
            }
            appCtx.startActivity(intent)
            InstallActionResult.OpenedSystemInstaller("📲 Đã mở trình cài đặt hệ thống. Bấm 'Cập nhật' để hoàn tất.")
        } catch (e: Throwable) {
            InstallActionResult.Error("Không thể mở trình cài đặt: ${e.message}")
        }
    }
}
