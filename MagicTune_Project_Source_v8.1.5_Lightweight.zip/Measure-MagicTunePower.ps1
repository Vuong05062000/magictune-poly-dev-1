<#
  Run over WLAN ADB, with the phone unplugged. Keep screen brightness, workload
  and network comparable between releases. Example:
    .\Measure-MagicTunePower.ps1 -Minutes 60 -Scenario MagicLive
  Reads Android's per-UID energy estimate twice. No reset, polling or APK changes.
#>
[CmdletBinding()]
param(
    [ValidateRange(1, 1440)][int]$Minutes = 60,
    [string]$Scenario = 'MagicTune',
    [string]$Serial
)

$ErrorActionPreference = 'Stop'
$package = 'com.magictune.tool'
$adb = (Get-Command adb -ErrorAction SilentlyContinue | Select-Object -First 1).Source
if (!$adb) { $adb = Join-Path $env:LOCALAPPDATA 'Android\Sdk\platform-tools\adb.exe' }
if (!(Test-Path -LiteralPath $adb)) { throw 'Android SDK platform-tools (adb) is required.' }
if (!$Serial) {
    $Serial = & $adb get-serialno
    if ($LASTEXITCODE -ne 0 -or !$Serial) { throw 'Connect one authorized phone via WLAN ADB, or select it with -Serial.' }
}

function Read-Sample {
    $battery = & $adb -s $Serial shell dumpsys battery
    if ($LASTEXITCODE -ne 0 -or !($battery -match '^\s*status:\s*3\s*$')) {
        throw 'The phone must be connected through WLAN ADB and discharging.'
    }
    $apps = & $adb -s $Serial shell pm list packages -U --user current $package
    $idLine = $apps | Select-String '^package:com\.magictune\.tool\s+uid:(\d+)\s*$' | Select-Object -First 1
    if (!$idLine) { throw 'MagicTune was not found for the active Android user.' }
    $appUid = $idLine.Matches[0].Groups[1].Value
    $stats = & $adb -s $Serial shell dumpsys batterystats -c --charged $package
    if ($LASTEXITCODE -ne 0) { throw 'Cannot read Android battery statistics.' }
    $power = $stats | Select-String "^\d+,$appUid,l,pwi,uid,([0-9.]+)," | Select-Object -First 1
    $timing = $stats | Where-Object { $_ -match '^\d+,0,l,bt,' } | Select-Object -First 1
    if (!$power -or !$timing) { throw 'This device has no usable per-UID energy or battery timing data for this session.' }
    $fields = $timing.Split(',')
    if ($fields.Count -lt 10) { throw 'Unrecognized Android battery timing record.' }
    [pscustomobject]@{
        AppUid = $appUid
        Energy = [double]::Parse($power.Matches[0].Groups[1].Value, [cultureinfo]::InvariantCulture)
        BatteryMs = [long]$fields[5]
        ElapsedMs = [long]$fields[7]
        Epoch = $fields[9]
        Starts = $fields[4]
    }
}

$start = Read-Sample
Write-Host "Using $Serial. Run $Scenario for $Minutes minutes with the phone unplugged."
Start-Sleep -Seconds ($Minutes * 60)
$end = Read-Sample
$elapsed = $end.ElapsedMs - $start.ElapsedMs
$onBattery = $end.BatteryMs - $start.BatteryMs
$energy = $end.Energy - $start.Energy
if ($start.AppUid -ne $end.AppUid -or $start.Epoch -ne $end.Epoch -or
    $start.Starts -ne $end.Starts -or $elapsed -le 0 -or $energy -lt 0 -or
    [math]::Abs($elapsed - $onBattery) -gt 3000) {
    throw 'The phone, UID, statistics period or charging state changed. Repeat the session.'
}
[pscustomobject]@{
    Scenario = $Scenario
    Minutes = [math]::Round($elapsed / 60000.0, 1)
    AndroidEstimatedAppMah = [math]::Round($energy, 3)
    AndroidEstimatedAppMahPerHour = [math]::Round($energy * 3600000.0 / $elapsed, 2)
}
