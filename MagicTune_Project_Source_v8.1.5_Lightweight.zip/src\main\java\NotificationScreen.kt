package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.HorizontalDivider
import androidx.compose.ui.platform.testTag
import com.example.data.DiagnosticScanResult
import com.example.ui.theme.MagicAmber
import com.example.ui.theme.MagicBorder
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicCyanLight
import com.example.ui.theme.MagicEmerald
import com.example.ui.theme.MagicEmeraldLight
import com.example.ui.theme.MagicPurple
import com.example.ui.theme.MagicRose
import com.example.ui.theme.MagicSurfaceCard
import com.example.ui.theme.MagicSurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun NotificationScreen(
    isBusy: Boolean,
    diagnosticScan: DiagnosticScanResult = DiagnosticScanResult(),
    onFixAllNotifications: () -> Unit,
    onBatchGrantPermissions: () -> Unit,
    onRunDiagnosticScan: () -> Unit = {},
    onResetAndRescan: () -> Unit = {},
    onFixSingleApp: (String, String) -> Unit = { _, _ -> },
    onOpenAppNotificationSettings: (String) -> Unit = {},
    onOpenAppDetailsSettings: (String) -> Unit = {},
    onFixFacebook: () -> Unit = {},
    onRestoreGmailAndFacebookDefault: () -> Unit = {},
    onBoostBatching: () -> Unit = {},
    onPrioritizeCustomSounds: () -> Unit = {},
    onRemovePowerGenius: () -> Unit = {},
    onTestNotification: (String, String) -> Unit = { _, _ -> },
    isChargingNotificationEnabled: Boolean = true,
    onToggleChargingNotification: (Boolean) -> Unit = {},
    isSearchNotificationEnabled: Boolean = false,
    onToggleSearchNotification: (Boolean) -> Unit = {},
    onNavigateToUniversalFix: () -> Unit = {}
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier.fillMaxSize().blockInputWhileBusy(isBusy),
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        // Ô #13: HỢP NHẤT MỞ KHÓA 100% THÔNG BÁO, TẮT POWERGENIUS & CẤP FULL QUYỀN PIN 24/7
        item(key = "notif_card_09", contentType = "feature_card") {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = BorderStroke(1.5.dp, remember { Brush.horizontalGradient(listOf(MagicCyan, MagicEmerald)) })
        ) {
            Column(
                modifier = Modifier.padding(9.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicCyan)
                                .padding(horizontal = 7.dp, vertical = 3.dp)
                        ) {
                            Text(text = "Ô #13", color = Color(0xFF020617), fontSize = 10.5.sp, fontWeight = FontWeight.Black)
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(MagicEmerald.copy(alpha = 0.2f))
                                .border(1.dp, MagicEmerald, RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "✓ Zero Delay",
                                color = MagicEmeraldLight,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Text(
                        text = "🔔 MỞ KHÓA 100% THÔNG BÁO, POWERGENIUS & PIN 24/7",
                        color = MagicCyanLight,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.fillMaxWidth()
                    )
                }



                Button(
                    onClick = onFixAllNotifications,
                    enabled = !isBusy,
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 36.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MagicCyan, contentColor = Color(0xFF020617))
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                        Icon(imageVector = Icons.Default.NotificationsActive, contentDescription = null, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "⚡ MỞ KHÓA 100% THÔNG BÁO TOÀN HỆ THỐNG",
                            fontSize = 12.2.sp,
                            fontWeight = FontWeight.Black,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onBatchGrantPermissions,
                        enabled = !isBusy,
                        modifier = Modifier
                            .fillMaxHeight().weight(1f)
                            .defaultMinSize(minHeight = 36.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MagicEmerald, contentColor = Color(0xFF020617))
                    ) {
                        Text(
                            text = "🛡️ Cấp Full Quyền Pin\n& Chạy Ngầm 24/7",
                            fontSize = 11.2.sp,
                            fontWeight = FontWeight.Black,
                            textAlign = TextAlign.Center,
                            lineHeight = 14.5.sp
                        )
                    }

                    Button(
                        onClick = onRemovePowerGenius,
                        enabled = !isBusy,
                        modifier = Modifier
                            .fillMaxHeight().weight(1f)
                            .defaultMinSize(minHeight = 36.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MagicAmber, contentColor = Color(0xFF020617))
                    ) {
                        Text(
                            text = "⚡ Tắt PowerGenius\n& Phá Gom Cụm Ngầm",
                            fontSize = 11.2.sp,
                            fontWeight = FontWeight.Black,
                            textAlign = TextAlign.Center,
                            lineHeight = 14.5.sp
                        )
                    }
                }
            }
        }
        }

        // Ô #14: BẢNG SỬA TẮT TỪNG ỨNG DỤNG MẠNG XÃ HỘI CỤ THỂ
        item(key = "notif_card_10", contentType = "feature_card") {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = BorderStroke(1.dp, MagicBorder)
        ) {
            Column(
                modifier = Modifier.padding(9.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicPurple)
                                .padding(horizontal = 7.dp, vertical = 3.dp)
                        ) {
                            Text(text = "Ô #14", color = Color.White, fontSize = 10.5.sp, fontWeight = FontWeight.Black)
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicEmerald.copy(alpha = 0.18f))
                                .border(1.dp, MagicEmerald.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 7.dp, vertical = 2.dp)
                        ) {
                            Text("✓ 5 Ứng Dụng Chính", color = MagicEmeraldLight, fontSize = 9.5.sp, fontWeight = FontWeight.Black)
                        }
                    }
                    Text(
                        text = "📱 ĐẶC TRỊ LỖI CÂM LẶNG & TRỄ TIN NHẮN TỪNG APP",
                        color = Color.White,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                val popularApps = listOf(
                    Triple("Messenger", "com.facebook.orca", "Mở biểu ngữ nổi & bong bóng chat trực tiếp (Meta)"),
                    Triple("Instagram", "com.instagram.android", "Giữ đầy đủ thông báo tin nhắn Direct & bài đăng (Meta)"),
                    Triple("WhatsApp", "com.whatsapp", "Mở khóa chạy ngầm 24/7 & chuông cuộc gọi (Meta)"),
                    Triple("Zalo", "com.zing.zalo", "Mở khóa chạy ngầm 24/7 & chuông thông báo cuộc gọi"),
                    Triple("Gmail", "com.google.android.gm", "Phá gom cụm 0s, nhận mail lập tức không trễ")
                )

                popularApps.forEach { (appName, pkg, desc) ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF0F172A))
                            .border(1.dp, MagicBorder, RoundedCornerShape(12.dp))
                            .padding(10.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(text = appName, color = MagicCyanLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Row(
                                modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Button(
                                    onClick = { onFixSingleApp(pkg, appName) },
                                    modifier = Modifier.fillMaxHeight().weight(1f).heightIn(min = 34.dp),
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp),
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = MagicCyan.copy(alpha = 0.2f), contentColor = MagicCyan)
                                ) {
                                    Text(text = "⚡ Sửa Ngay", color = MagicCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                                }
                                Button(
                                    onClick = { onTestNotification(pkg, appName) },
                                    modifier = Modifier.fillMaxHeight().weight(1f).heightIn(min = 34.dp),
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp),
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = MagicEmerald.copy(alpha = 0.2f), contentColor = MagicEmeraldLight)
                                ) {
                                    Text(text = "🔔 Thử Ring", color = MagicEmeraldLight, fontSize = 10.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                                }
                                Button(
                                    onClick = { onOpenAppNotificationSettings(pkg) },
                                    modifier = Modifier.fillMaxHeight().weight(0.85f).heightIn(min = 34.dp),
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp),
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = MagicPurple.copy(alpha = 0.25f), contentColor = Color.White)
                                ) {
                                    Text(text = "⚙️ Kênh", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                                }
                                Button(
                                    onClick = { onOpenAppDetailsSettings(pkg) },
                                    modifier = Modifier.fillMaxHeight().weight(0.85f).heightIn(min = 34.dp),
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp),
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = MagicAmber.copy(alpha = 0.2f), contentColor = MagicAmber)
                                ) {
                                    Text(text = "🔋 Pin", color = MagicAmber, fontSize = 10.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                                }
                            }
                        }
                    }
                }
            }
        }
        }

        // Ô #15: BẢNG CÔNG TẮC TIỆN ÍCH THANH THÔNG BÁO
        item(key = "notif_card_11", contentType = "feature_card") {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard)
        ) {
            Column(
                modifier = Modifier.padding(9.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicAmber)
                                .padding(horizontal = 7.dp, vertical = 3.dp)
                        ) {
                            Text(text = "Ô #15", color = Color(0xFF020617), fontSize = 10.5.sp, fontWeight = FontWeight.Black)
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicCyan.copy(alpha = 0.18f))
                                .padding(horizontal = 7.dp, vertical = 2.dp)
                        ) {
                            Text("✓ Tiện Ích Nhanh", color = MagicCyanLight, fontSize = 9.5.sp, fontWeight = FontWeight.Black)
                        }
                    }
                    Text(
                        text = "⚙️ TÙY CHỌN TIỆN ÍCH THANH THÔNG BÁO",
                        color = Color.White,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // Switch 1: Ghim tìm kiếm
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.fillMaxHeight().weight(1f)) {
                        Text("Ghim ô tìm kiếm nhanh trên thanh thông báo", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("Mở nhanh các tính năng và ứng dụng ngay từ mép vuốt trên", color = TextMuted, fontSize = 10.5.sp)
                    }
                    Switch(
                        checked = isSearchNotificationEnabled,
                        onCheckedChange = onToggleSearchNotification,
                        colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = MagicCyan)
                    )
                }

                // Switch 2: Hiển thị công suất sạc
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.fillMaxHeight().weight(1f)) {
                        Text("Hiển thị Watt sạc pin thời gian thực", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("Cập nhật dòng điện (V, mA, Watt) liên tục khi cắm sạc", color = TextMuted, fontSize = 10.5.sp)
                    }
                    Switch(
                        checked = isChargingNotificationEnabled,
                        onCheckedChange = onToggleChargingNotification,
                        colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = MagicEmerald)
                    )
                }

                // Không quảng cáo tính năng đánh thức màn hình nền: app không thể tự bật màn hình
                // cho thông báo của app khác và tuần tra nền đã bị vô hiệu hóa để tránh hao pin.
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.fillMaxHeight().weight(1f)) {
                        Text("Đánh thức màn hình khi có thông báo: đã tắt", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("MagicTune không chạy tuần tra nền để bật màn hình; hãy cấu hình thông báo màn hình khóa trong Cài đặt Android.", color = TextMuted, fontSize = 10.5.sp)
                    }
                }
            }
        }
        }

        // Ô #16: ƯU TIÊN CHUÔNG & ÂM THANH TÙY CHỈNH CHO TIN NHẮN
        item(key = "notif_card_12", contentType = "feature_card") {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
            border = BorderStroke(1.dp, MagicBorder)
        ) {
            Column(
                modifier = Modifier.padding(9.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicPurple)
                                .padding(horizontal = 7.dp, vertical = 3.dp)
                        ) {
                            Text(text = "Ô #16", color = Color.White, fontSize = 10.5.sp, fontWeight = FontWeight.Black)
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicEmerald.copy(alpha = 0.18f))
                                .padding(horizontal = 7.dp, vertical = 2.dp)
                        ) {
                            Text("✓ Ưu Tiên Chuông", color = MagicEmeraldLight, fontSize = 9.5.sp, fontWeight = FontWeight.Black)
                        }
                    }
                    Text(
                        text = "🔊 ƯU TIÊN CHUÔNG & ÂM THANH TIN NHẮN TÙY CHỈNH",
                        color = Color.White,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Button(
                    onClick = onPrioritizeCustomSounds,
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 34.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MagicPurple, contentColor = Color.White)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                        Icon(imageVector = Icons.Default.VolumeUp, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "Ưu Tiên Âm Thanh Chuông Cao Nhất", fontSize = 11.5.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
                    }
                }
            }
        }
        }

        // Ô #17: HỢP NHẤT ĐẶC TRỊ FCM FACEBOOK & TỰ KHỞI CHẠY MẠNG XÃ HỘI (AUTO-START)
        item(key = "notif_card_13", contentType = "feature_card") {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
            border = BorderStroke(1.dp, MagicBorder)
        ) {
            Column(
                modifier = Modifier.padding(9.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicCyan)
                                .padding(horizontal = 7.dp, vertical = 3.dp)
                        ) {
                            Text(text = "Ô #17", color = Color(0xFF020617), fontSize = 10.5.sp, fontWeight = FontWeight.Black)
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicEmerald.copy(alpha = 0.18f))
                                .padding(horizontal = 7.dp, vertical = 2.dp)
                        ) {
                            Text("✓ FCM & Auto-Start", color = MagicEmeraldLight, fontSize = 9.5.sp, fontWeight = FontWeight.Black)
                        }
                    }
                    Text(
                        text = "📲 ĐẶC TRỊ FCM META & AUTO-START MXH (TRỪ FB CHÍNH)",
                        color = Color.White,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Button(
                    onClick = onFixFacebook,
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 34.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MagicCyan, contentColor = Color(0xFF020617))
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "Fix FCM Meta & Bật Auto-Start MXH Ngay", fontSize = 11.5.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
                    }
                }
            }
        }
        }

        // Ô #18: HỢP NHẤT PHÁ GOM CỤM 0S GMAIL PUSH & ƯU TIÊN CUỘC GỌI VOLTE / VOWIFI
        item(key = "notif_card_14", contentType = "feature_card") {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
            border = BorderStroke(1.dp, MagicBorder)
        ) {
            Column(
                modifier = Modifier.padding(9.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicEmerald)
                                .padding(horizontal = 7.dp, vertical = 3.dp)
                        ) {
                            Text(text = "Ô #18", color = Color(0xFF020617), fontSize = 10.5.sp, fontWeight = FontWeight.Black)
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicEmerald.copy(alpha = 0.18f))
                                .padding(horizontal = 7.dp, vertical = 2.dp)
                        ) {
                            Text("✓ Push 0s & VoLTE", color = MagicEmeraldLight, fontSize = 9.5.sp, fontWeight = FontWeight.Black)
                        }
                    }
                    Text(
                        text = "📩 PHÁ GOM CỤM 0S GMAIL & ƯU TIÊN VOLTE / VOWIFI",
                        color = Color.White,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Button(
                    onClick = onBoostBatching,
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 34.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MagicEmerald, contentColor = Color(0xFF020617))
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                        Icon(imageVector = Icons.Default.FlashOn, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "Kích Hoạt Mail Push 0s & Ưu Tiên Cuộc Gọi 24/7", fontSize = 11.5.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
                    }
                }
                OutlinedButton(
                    onClick = onRestoreGmailAndFacebookDefault,
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 32.dp),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, MagicAmber.copy(alpha = 0.5f))
                ) {
                    Text(
                        text = "🔄 Khôi Phục Mặc Định Gmail & Meta",
                        color = MagicAmber,
                        fontSize = 10.8.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
        }

        // Ô #19: KHUYẾN NGHỊ WEB-ADB QUA USB (https://magictunehonor.ai.studio/) & CHẨN ĐOÁN TIẾN TRÌNH NGẦM
        item(key = "notif_card_15", contentType = "feature_card") {
        val webAdbUrl = "https://magictunehonor.ai.studio/"
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
            border = BorderStroke(1.2.dp, MagicCyan.copy(alpha = 0.45f))
        ) {
            Column(
                modifier = Modifier.padding(9.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicPurple)
                                .padding(horizontal = 7.dp, vertical = 3.dp)
                        ) {
                            Text(text = "Ô #19", color = Color.White, fontSize = 10.5.sp, fontWeight = FontWeight.Black)
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicAmber.copy(alpha = 0.18f))
                                .border(1.dp, MagicAmber.copy(alpha = 0.45f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 7.dp, vertical = 2.dp)
                        ) {
                            Text("🔌 Khuyên Dùng WebADB USB", color = MagicAmber, fontSize = 9.5.sp, fontWeight = FontWeight.Black)
                        }
                    }
                    Text(
                        text = "🔌 SỬA THÔNG BÁO & BIỂU NGỮ HÀNG LOẠT QUA WEB USB",
                        color = Color.White,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // Khung nhắc nhở WebADB qua USB thay thế PiP/WLAN HUD không hiệu quả trên Cài đặt
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            Brush.verticalGradient(
                                listOf(Color(0xFF0F172A), Color(0xFF0A1222))
                            )
                        )
                        .border(1.dp, MagicAmber.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Lưu ý WebADB qua USB",
                            tint = MagicAmber,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "Vì sao không dùng cửa sổ PiP trên trang Cài đặt?",
                            color = MagicAmber,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Text(
                        text = "Cửa sổ nổi PiP không hoạt động ổn định trên trang Cài đặt hệ thống và gỡ lỗi qua WLAN không thể tự động điều khiển màn hình Cài đặt để bật Biểu ngữ hay tắt Thông báo nhẹ nhàng cho từng app.",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 15.5.sp
                    )
                    Text(
                        text = "👉 Để bật/tắt sửa lỗi thông báo & biểu ngữ hàng loạt hiệu quả hơn, hãy dùng bản WebADB gỡ lỗi qua cáp USB tại:",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        lineHeight = 15.5.sp
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MagicCyan.copy(alpha = 0.12f))
                            .border(1.dp, MagicCyan.copy(alpha = 0.45f), RoundedCornerShape(8.dp))
                            .clickable {
                                try {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(webAdbUrl)).apply {
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                    context.startActivity(intent)
                                } catch (_: Throwable) {
                                    Toast.makeText(context, "Vui lòng truy cập $webAdbUrl trên trình duyệt máy tính", Toast.LENGTH_LONG).show()
                                }
                            }
                            .padding(horizontal = 10.dp, vertical = 9.dp)
                    ) {
                        Text(
                            text = webAdbUrl,
                            color = MagicCyanLight,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                try {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(webAdbUrl)).apply {
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                    context.startActivity(intent)
                                } catch (_: Throwable) {
                                    Toast.makeText(context, "Không mở được trình duyệt. Link: $webAdbUrl", Toast.LENGTH_LONG).show()
                                }
                            },
                            modifier = Modifier
                                .fillMaxHeight().weight(1.3f)
                                .defaultMinSize(minHeight = 36.dp)
                                .testTag("open_webadb_usb_button"),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MagicCyan, contentColor = Color(0xFF020617))
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.OpenInNew,
                                    contentDescription = "Mở trang WebADB USB",
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Mở WebADB USB",
                                    fontSize = 11.2.sp,
                                    fontWeight = FontWeight.Black,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }

                        OutlinedButton(
                            onClick = {
                                try {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                                    clipboard?.setPrimaryClip(ClipData.newPlainText("WebADB URL", webAdbUrl))
                                    Toast.makeText(context, "✅ Đã sao chép: $webAdbUrl", Toast.LENGTH_SHORT).show()
                                } catch (_: Throwable) {
                                    Toast.makeText(context, webAdbUrl, Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier
                                .fillMaxHeight().weight(1f)
                                .defaultMinSize(minHeight = 36.dp)
                                .testTag("copy_webadb_url_button"),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, MagicEmerald.copy(alpha = 0.6f))
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ContentCopy,
                                    contentDescription = "Sao chép link WebADB",
                                    tint = MagicEmeraldLight,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = "Sao Chép Link",
                                    color = MagicEmeraldLight,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }

                HorizontalDivider(color = MagicBorder.copy(alpha = 0.5f))

                Text(
                    text = "📊 Kiểm tra nhanh các dịch vụ chạy ngầm & quyền ứng dụng qua ADB hiện tại:",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
                Row(
                    modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onRunDiagnosticScan,
                        modifier = Modifier
                            .fillMaxHeight().weight(1.3f)
                            .defaultMinSize(minHeight = 36.dp)
                            .testTag("run_diagnostic_scan_button"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MagicPurple, contentColor = Color.White)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                            if (diagnosticScan.isScanning) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = "Đang quét...", fontSize = 11.sp, fontWeight = FontWeight.Black)
                            } else {
                                Icon(imageVector = Icons.Default.Search, contentDescription = "Quét tiến trình ngầm", modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = "Quét Tiến Trình Ngầm", fontSize = 11.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                    OutlinedButton(
                        onClick = onResetAndRescan,
                        modifier = Modifier
                            .fillMaxHeight().weight(0.7f)
                            .defaultMinSize(minHeight = 36.dp)
                            .testTag("reset_rescan_button"),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.5f))
                    ) {
                        Text(text = "🔄 Quét Mới", color = MagicCyanLight, fontSize = 10.8.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                    }
                }

                // Hiển thị kết quả quét giám sát tiến trình ngầm
                if (diagnosticScan.isScanning) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(MagicPurple.copy(alpha = 0.15f))
                            .border(1.dp, MagicPurple.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                            .padding(12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = MagicPurple, strokeWidth = 2.dp)
                            Text(text = "⏳ Đang phân tích các dịch vụ ngầm & nguyên nhân hoãn thông báo...", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                } else if (diagnosticScan.hasScanned) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (diagnosticScan.totalRemainingIssues == 0) MagicEmerald.copy(alpha = 0.18f) else MagicRose.copy(alpha = 0.18f))
                                .border(1.dp, if (diagnosticScan.totalRemainingIssues == 0) MagicEmerald else MagicRose, RoundedCornerShape(10.dp))
                                .padding(12.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = if (diagnosticScan.totalRemainingIssues == 0)
                                        "🎉 HỆ THỐNG HOÀN HẢO (0 LỖI TRỄ)"
                                    else
                                        "⚠️ PHÁT HIỆN ${diagnosticScan.totalRemainingIssues} TIẾN TRÌNH CẦN TỐI ƯU",
                                    color = if (diagnosticScan.totalRemainingIssues == 0) MagicEmeraldLight else Color(0xFFFF8888),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Black
                                )
                                Text(
                                    text = "Đã quét ${diagnosticScan.allScannedAppsCount} ứng dụng lúc ${diagnosticScan.lastScanTime}",
                                    color = TextSecondary,
                                    fontSize = 10.5.sp
                                )
                            }
                        }

                        if (diagnosticScan.systemDelayCauses.isNotEmpty()) {
                            Text(text = "🚨 Tác nhân diệt ngầm hệ thống:", color = MagicAmber, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            diagnosticScan.systemDelayCauses.forEach { cause ->
                                androidx.compose.runtime.key(cause.title) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color(0xFF020617))
                                            .padding(8.dp),
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(5.dp))
                                                .background(if (cause.isFixed) MagicEmerald.copy(alpha = 0.16f) else MagicRose.copy(alpha = 0.16f))
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = if (cause.isFixed) "✅ Đã sửa" else "⚠️ Chưa sửa",
                                                color = if (cause.isFixed) MagicEmeraldLight else MagicRose,
                                                fontSize = 9.5.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                        Text(
                                            text = cause.title,
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                        Text(
                                            text = cause.description,
                                            color = TextMuted,
                                            fontSize = 10.sp,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                }
                            }
                        }

                        val issueApps = remember(diagnosticScan.gentleAndBannerApps, diagnosticScan.missingPermissionApps) {
                            (diagnosticScan.gentleAndBannerApps + diagnosticScan.missingPermissionApps).distinctBy { it.packageName }
                        }
                        if (issueApps.isNotEmpty()) {
                            Text(text = "📲 Ứng dụng cần mở kênh / quyền ngầm (${issueApps.size}):", color = MagicCyanLight, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            issueApps.take(6).forEach { app ->
                                androidx.compose.runtime.key(app.packageName) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color(0xFF020617))
                                            .padding(8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = app.appName,
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.fillMaxHeight().weight(1f).padding(end = 4.dp)
                                        )
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(MagicPurple.copy(alpha = 0.25f))
                                                .clickable { onOpenAppNotificationSettings(app.packageName) }
                                                .padding(horizontal = 8.dp, vertical = 6.dp)
                                        ) {
                                            Text(text = "⚙️ Kênh", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        }
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(MagicCyan.copy(alpha = 0.2f))
                                                .clickable { onFixSingleApp(app.packageName, app.appName) }
                                                .padding(horizontal = 8.dp, vertical = 6.dp)
                                        ) {
                                            Text(text = "⚡ Fix Quyền", color = MagicCyanLight, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }

                        if (diagnosticScan.totalRemainingIssues > 0) {
                            Button(
                                onClick = onFixAllNotifications,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .defaultMinSize(minHeight = 36.dp)
                                    .testTag("fix_all_notifications_from_scan_button"),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MagicEmerald, contentColor = Color(0xFF020617))
                            ) {
                                Text(text = "⚡ CẤP QUYỀN & SỬA LỖI ADB (${diagnosticScan.totalRemainingIssues} MỤC)", fontWeight = FontWeight.Black, fontSize = 11.5.sp, textAlign = TextAlign.Center)
                            }
                        }
                    }
                }
            }
        }
        }

        item(key = "notif_footer", contentType = "footer") {
            HonorOptimizationDisclaimerFooter(onNavigateToUniversalFix = onNavigateToUniversalFix)
        }
    }
}
