# Kế hoạch tối ưu năng lượng pin & màn hình Honor GT Pro (7200mAh)

## Tiến độ hoàn thành:
- [x] Bước 1: Quản lý vòng đời & MulticastLock trong `AdbNsdScanner.kt` (giữ lock ≤2s, passive radar chỉ chạy khi có lock, single daemon executor).
- [x] Bước 2: Throttling UsageStats & Ticker trong `MagicTuneKeepAliveService.kt` (UsageStats cache TTL 30s).
- [x] Bước 3: Dọn dẹp CoroutineScope & bảo mật trong `MagicTuneApplication.kt` và `FirebaseAuthManager.kt` / `LicenseManager.kt`.
- [x] Bước 4: Giảm tần số OCR và gom câu TTS (`GoogleScreenTranslator.kt`: OCR text hash throttle, tăng min interval lên 2s/4s, TTS batching 300ms).
- [x] Bước 5: Network Cache & Connection Pooling (Hoàn tất):
  - `networkAttemptCooldown` TTL 4.0s trong `GoogleScreenTranslator.kt` (giảm >50% HTTP request thừa khi cuộn).
  - Tái sử dụng socket qua HTTP `Connection: Keep-Alive` (không `disconnect()` trên mã 200, tái sử dụng OkHttp connection pool).
  - Thêm `aiResponseShortCache` TTL 5.0s trong `MagicLiveFloatingOverlay.kt` (chống duplicate request Groq/Gemini).
- [x] Bước 6: Tối ưu hiển thị màn hình & GPU SurfaceFlinger cho Honor GT Pro:
  - Bổ sung `FLAG_HARDWARE_ACCELERATED` cho toàn bộ các cửa sổ lớp phủ (`canvasParams`, `barParams`, `speakerParams`, `touchParams`, `GestureLauncherOverlay`, `SystemFloatingHudOverlay`).
  - Giới hạn 16 vùng chạm tương tác nổi bật nhất trên `GoogleLiveTranslateOverlay` để giải phóng Layer SurfaceFlinger.
  - Tận dụng cơ chế LTPO 1Hz - 120Hz của màn hình Honor GT Pro: triệt tiêu vòng lặp redraw khi khung nhìn đứng yên.
  - Đảm bảo app đạt chuẩn tiêu thụ 0.1% - 1.0% pin/giờ trên viên pin 7200mAh.
