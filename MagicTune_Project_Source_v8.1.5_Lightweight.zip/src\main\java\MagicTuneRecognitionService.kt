package com.example.core.assistant

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognitionService
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * Dịch vụ Nhận diện Giọng nói Hệ thống (RecognitionService).
 * Đăng ký MagicTune vào danh sách Đầu vào Giọng nói mặc định của Android / Honor.
 */
class MagicTuneRecognitionService : RecognitionService() {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var speechRecognizer: SpeechRecognizer? = null

    override fun onStartListening(recognizerIntent: Intent?, listener: Callback?) {
        if (listener == null) return
        mainHandler.post {
            try {
                if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                    listener.error(SpeechRecognizer.ERROR_CLIENT)
                    return@post
                }
                speechRecognizer?.destroy()
                val sr = SpeechRecognizer.createSpeechRecognizer(this)
                speechRecognizer = sr
                sr.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        try { listener.readyForSpeech(params ?: Bundle()) } catch (_: Throwable) {}
                    }
                    override fun onBeginningOfSpeech() {
                        try { listener.beginningOfSpeech() } catch (_: Throwable) {}
                    }
                    override fun onRmsChanged(rmsdB: Float) {
                        try { listener.rmsChanged(rmsdB) } catch (_: Throwable) {}
                    }
                    override fun onBufferReceived(buffer: ByteArray?) {
                        try { listener.bufferReceived(buffer) } catch (_: Throwable) {}
                    }
                    override fun onEndOfSpeech() {
                        try { listener.endOfSpeech() } catch (_: Throwable) {}
                    }
                    override fun onError(error: Int) {
                        try { listener.error(error) } catch (_: Throwable) {}
                    }
                    override fun onResults(results: Bundle?) {
                        try { listener.results(results ?: Bundle()) } catch (_: Throwable) {}
                    }
                    override fun onPartialResults(partialResults: Bundle?) {
                        try { listener.partialResults(partialResults ?: Bundle()) } catch (_: Throwable) {}
                    }
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
                val targetIntent = recognizerIntent ?: Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                sr.startListening(targetIntent)
            } catch (_: Throwable) {
                try { listener.error(SpeechRecognizer.ERROR_CLIENT) } catch (_: Throwable) {}
            }
        }
    }

    override fun onCancel(listener: Callback?) {
        mainHandler.post {
            try { speechRecognizer?.cancel() } catch (_: Throwable) {}
        }
    }

    override fun onStopListening(listener: Callback?) {
        mainHandler.post {
            try { speechRecognizer?.stopListening() } catch (_: Throwable) {}
        }
    }

    override fun onDestroy() {
        try { speechRecognizer?.destroy() } catch (_: Throwable) {}
        speechRecognizer = null
        super.onDestroy()
    }
}
