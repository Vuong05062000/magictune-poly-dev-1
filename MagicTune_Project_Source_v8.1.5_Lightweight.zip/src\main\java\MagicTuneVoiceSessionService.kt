package com.example.core.assistant

import android.app.assist.AssistContent
import android.app.assist.AssistStructure
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import android.os.Bundle
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.view.View
import com.example.core.service.NoAccessibilityScreenEngine
import com.example.core.widget.MagicLiveFloatingOverlay
import kotlin.math.max

/**
 * Phiên Tương Tác Trợ Lý Hệ Thống (VoiceInteractionSessionService).
 * 1. Đón nhận tín hiệu khi người dùng gọi "Ok Google", nhấn nút nguồn hoặc cử chỉ góc màn hình để mở Trợ lý Magic.
 * 2. Nhận trực tiếp ảnh chụp màn hình (`onHandleScreenshot`) và cây cấu trúc giao diện (`AssistStructure` trong `onHandleAssist`)
 *    từ hệ điều hành Android mà KHÔNG CẦN QUYỀN TRỢ NĂNG (Accessibility), vượt 100% kiểm tra bảo mật của MB Bank & VNeID!
 */
class MagicTuneVoiceSessionService : VoiceInteractionSessionService() {

    override fun onNewSession(args: Bundle?): VoiceInteractionSession {
        return MagicTuneVoiceSession(this)
    }

    private class MagicTuneVoiceSession(context: Context) : VoiceInteractionSession(context) {

        private var isSilentCaptureMode = false
        @Volatile private var hasHandledAssist = false
        @Volatile private var hasHandledScreenshot = false

        override fun onCreateContentView(): View {
            try {
                window?.window?.addFlags(
                    android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        android.view.WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        android.view.WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                )
            } catch (_: Throwable) {}
            // Trả về View 1x1 trong suốt để không làm nháy màn hình khi chụp ngầm hoặc mở MagicLiveFloatingOverlay
            return View(context).apply {
                alpha = 0f
            }
        }

        private fun finishSessionAndOpenOverlayIfNeeded() {
            if (hasHandledAssist && hasHandledScreenshot) {
                val isSilent = isSilentCaptureMode ||
                    MagicTuneVoiceInteractionService.isSilentCaptureInProgress ||
                    com.example.core.widget.CircleToSearchOverlayActivity.isOverlayActive ||
                    com.example.core.widget.GoogleLiveTranslateOverlay.isRunning
                if (!isSilent) {
                    val ctx = context
                    android.os.Handler(android.os.Looper.getMainLooper()).post {
                        val activeMode = com.example.core.service.SystemFloatingHudOverlay.getActiveNavModMode(ctx)
                        if (activeMode == "CIRCLE_TO_SEARCH") {
                            if (!com.example.core.widget.CircleToSearchOverlayActivity.isOverlayActive) {
                                com.example.core.widget.CircleToSearchOverlayActivity.launch(ctx)
                            }
                        } else {
                            if (!com.example.core.widget.CircleToSearchOverlayActivity.isOverlayActive) {
                                val shown = MagicLiveFloatingOverlay.showAndStartListening(ctx)
                                if (!shown) {
                                    com.example.core.widget.MagicLiveLockscreenActivity.launchFromOverlay(ctx)
                                }
                            }
                        }
                    }
                }
                hide()
            }
        }

        override fun onShow(args: Bundle?, showFlags: Int) {
            super.onShow(args, showFlags)
            try {
                window?.window?.addFlags(
                    android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        android.view.WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        android.view.WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                )
            } catch (_: Throwable) {}
            isSilentCaptureMode = args?.getBoolean(MagicTuneVoiceInteractionService.EXTRA_SILENT_CAPTURE, false) == true ||
                MagicTuneVoiceInteractionService.isSilentCaptureInProgress ||
                com.example.core.widget.CircleToSearchOverlayActivity.isOverlayActive
            val expectsScreenshot = (showFlags and VoiceInteractionSession.SHOW_WITH_SCREENSHOT) != 0
            hasHandledAssist = false
            hasHandledScreenshot = !expectsScreenshot

            // Đặt timeout 950ms phòng trường hợp Android OS chậm trả callback trên màn hình độ phân giải cao 2K/4K
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                if (!hasHandledAssist || !hasHandledScreenshot) {
                    hasHandledAssist = true
                    hasHandledScreenshot = true
                    finishSessionAndOpenOverlayIfNeeded()
                }
            }, 950L)
        }

        @Suppress("DEPRECATION")
        override fun onHandleAssist(
            data: Bundle?,
            structure: AssistStructure?,
            content: AssistContent?
        ) {
            super.onHandleAssist(data, structure, content)
            try {
                if (structure != null) {
                    parseAndCacheAssistStructure(context, structure)
                }
            } catch (_: Throwable) {}
            MagicTuneVoiceInteractionService.pendingStructureDeferred?.complete(true)
            hasHandledAssist = true
            finishSessionAndOpenOverlayIfNeeded()
        }

        override fun onHandleScreenshot(screenshot: Bitmap?) {
            super.onHandleScreenshot(screenshot)
            try {
                val soft = try {
                    if (screenshot != null) {
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O && screenshot.config == Bitmap.Config.HARDWARE) {
                            screenshot.copy(Bitmap.Config.ARGB_8888, false) ?: screenshot
                        } else {
                            screenshot
                        }
                    } else null
                } catch (_: Throwable) {
                    screenshot
                }

                val optimized = if (soft != null) {
                    val maxAllowed = com.example.core.compat.DeviceCompatProfile.recommendedOcrMaxSidePx(context)
                    val maxSide = max(soft.width, soft.height)
                    if (maxSide > maxAllowed) {
                        val scale = maxAllowed.toFloat() / maxSide.toFloat()
                        val sw = (soft.width * scale).toInt().coerceAtLeast(1)
                        val sh = (soft.height * scale).toInt().coerceAtLeast(1)
                        val scaled = Bitmap.createScaledBitmap(soft, sw, sh, true)
                        if (scaled !== soft) {
                            try { soft.recycle() } catch (_: Throwable) {}
                        }
                        scaled
                    } else {
                        soft
                    }
                } else null

                if (optimized != null) {
                    val old = MagicTuneVoiceInteractionService.lastCapturedAssistBitmap
                    MagicTuneVoiceInteractionService.lastCapturedAssistBitmap = optimized
                    MagicTuneVoiceInteractionService.lastCapturedAssistTimeMs = System.currentTimeMillis()
                    if (old != null && old !== optimized && !old.isRecycled &&
                        !com.example.core.widget.CircleToSearchOverlayActivity.isOverlayActive
                    ) {
                        try { old.recycle() } catch (_: Throwable) {}
                    }
                }
                MagicTuneVoiceInteractionService.pendingScreenshotDeferred?.complete(optimized)
            } catch (_: Throwable) {
                MagicTuneVoiceInteractionService.pendingScreenshotDeferred?.complete(null)
            } finally {
                hasHandledScreenshot = true
                finishSessionAndOpenOverlayIfNeeded()
            }
        }

        override fun onHide() {
            super.onHide()
            isSilentCaptureMode = false
            hasHandledAssist = false
            hasHandledScreenshot = false
        }

        private fun parseAndCacheAssistStructure(context: Context, structure: AssistStructure) {
            val dm = context.resources.displayMetrics
            val screenW = dm.widthPixels.coerceAtLeast(1)
            val screenH = dm.heightPixels.coerceAtLeast(1)
            val ownPkg = context.packageName
            val compPkg = structure.activityComponent?.packageName.orEmpty()
            val isCompOwnPkg = (compPkg == ownPkg)

            val collected = mutableListOf<NoAccessibilityScreenEngine.UiNodeRecord>()
            var detectedPkg = ""

            val winCount = structure.windowNodeCount
            for (wIdx in 0 until winCount) {
                val winNode = structure.getWindowNodeAt(wIdx) ?: continue
                val winTitle = winNode.title?.toString().orEmpty()
                // Bỏ qua các cửa sổ của MagicTune nếu có nhiều cửa sổ, ưu tiên cửa sổ ứng dụng người dùng đang mở bên dưới
                if (winCount > 1 && winTitle.contains(ownPkg)) continue

                val root = winNode.rootViewNode ?: continue
                val winLeft = winNode.left
                val winTop = winNode.top

                fun walk(node: AssistStructure.ViewNode, parentAbsX: Int, parentAbsY: Int, depth: Int) {
                    if (depth > 95 || collected.size > 1800) return
                    val absX = parentAbsX + node.left
                    val absY = parentAbsY + node.top
                    val w = node.width
                    val h = node.height
                    val idPkg = node.idPackage?.trim().orEmpty()
                    if (detectedPkg.isEmpty() && idPkg.isNotBlank() && idPkg != ownPkg && idPkg != "com.android.systemui" && idPkg != "android") {
                        detectedPkg = idPkg
                    }
                    val effectivePkg = when {
                        !isCompOwnPkg && compPkg.isNotBlank() -> compPkg
                        idPkg.isNotBlank() && idPkg != "android" && idPkg != ownPkg -> idPkg
                        else -> detectedPkg
                    }

                    if (node.visibility == View.VISIBLE && w >= 6 && h >= 8 && effectivePkg != ownPkg) {
                        val rect = Rect(
                            absX.coerceIn(0, screenW),
                            absY.coerceIn(0, screenH),
                            (absX + w).coerceIn(0, screenW),
                            (absY + h).coerceIn(0, screenH)
                        )
                        val text = node.text?.toString()?.trim().orEmpty()
                        val desc = node.contentDescription?.toString()?.trim().orEmpty()
                        val hint = node.hint?.trim().orEmpty()
                        val cls = node.className?.trim().orEmpty()
                        val resId = node.idEntry?.trim().orEmpty()

                        if (rect.width() >= 6 && rect.height() >= 8 && (text.isNotEmpty() || desc.isNotEmpty() || hint.isNotEmpty() || node.isClickable || node.isCheckable)) {
                            collected.add(
                                NoAccessibilityScreenEngine.UiNodeRecord(
                                    text = text,
                                    contentDesc = desc,
                                    hint = hint,
                                    className = cls,
                                    resourceId = resId,
                                    packageName = effectivePkg,
                                    isClickable = node.isClickable,
                                    isCheckable = node.isCheckable,
                                    isChecked = node.isChecked,
                                    bounds = rect
                                )
                            )
                        }
                    }

                    val childOriginX = absX - node.scrollX
                    val childOriginY = absY - node.scrollY
                    val childCount = node.childCount
                    for (i in 0 until childCount) {
                        val child = node.getChildAt(i) ?: continue
                        walk(child, childOriginX, childOriginY, depth + 1)
                    }
                }

                walk(root, winLeft, winTop, 0)
            }

            val finalPkg = when {
                compPkg.isNotBlank() && compPkg != ownPkg && compPkg != "com.android.systemui" -> compPkg
                detectedPkg.isNotBlank() -> detectedPkg
                else -> ""
            }
            if (collected.isNotEmpty()) {
                NoAccessibilityScreenEngine.updateAssistStructureCache(context, collected, finalPkg)
            }
        }
    }
}
