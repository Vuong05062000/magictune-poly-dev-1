package com.example.core.widget

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VietnameseLunarCalendarTest {

    @Test
    fun `tet nguyen dan dates convert accurately`() {
        val tet2024 = VietnameseLunarCalendar.convertSolar2Lunar(10, 2, 2024)
        assertEquals(1, tet2024.day)
        assertEquals(1, tet2024.month)
        assertEquals(2024, tet2024.year)
        assertFalse(tet2024.isLeapMonth)
        assertEquals("Giáp Thìn", tet2024.yearCanChi)
        assertEquals("Giáp Thìn", tet2024.dayCanChi)

        val tet2025 = VietnameseLunarCalendar.convertSolar2Lunar(29, 1, 2025)
        assertEquals(1, tet2025.day)
        assertEquals(1, tet2025.month)
        assertEquals(2025, tet2025.year)
        assertEquals("Ất Tỵ", tet2025.yearCanChi)

        val tet2026 = VietnameseLunarCalendar.convertSolar2Lunar(17, 2, 2026)
        assertEquals(1, tet2026.day)
        assertEquals(1, tet2026.month)
        assertEquals(2026, tet2026.year)
        assertEquals("Bính Ngọ", tet2026.yearCanChi)
    }

    @Test
    fun `november 2026 grid has 42 cells and valid lunar days`() {
        val grid = VietnameseLunarCalendar.buildMonthGrid(2026, 11)
        assertEquals(42, grid.size)
        val nov1 = grid.first { it.isCurrentMonth && it.solarDay == 1 }
        // 1/11/2026 is Sunday -> col 6
        assertEquals(6, nov1.dayOfWeekCol)
        assertTrue(nov1.lunar.day in 1..30)
        assertEquals("Bính Ngọ", nov1.lunar.yearCanChi)

        val nov17 = grid.first { it.isCurrentMonth && it.solarDay == 17 }
        // 17/11/2026 is Tuesday -> col 1
        assertEquals(1, nov17.dayOfWeekCol)
        assertTrue(nov17.lunar.month == 10)
    }
}
