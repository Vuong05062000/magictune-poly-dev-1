package com.example.core.widget

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaDataSource
import android.media.MediaPlayer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import kotlin.coroutines.EmptyCoroutineContext
import kotlin.coroutines.resume

/** One spoken reply. Player and system TTS lifecycle run on Main. */
internal class MagicLiveSpeechOutput(private val context: Context) {
    private var systemTts: TextToSpeech? = null
    private var systemTtsReady = false

    suspend fun speak(chunks: List<String>) = coroutineScope {
        if (chunks.isEmpty()) return@coroutineScope
        try {
            var next = async { download(chunks.first()) }
            for ((index, chunk) in chunks.withIndex()) {
                val audio = next.await()
                chunks.getOrNull(index + 1)?.let { upcoming ->
                    next = async { download(upcoming) }
                }
                if (audio == null || audio.size <= 256 || !play(audio)) {
                    speakWithSystemTts(chunk, index.toString())
                }
            }
        } finally {
            systemTts?.let { engine ->
                try { engine.stop() } finally { engine.shutdown() }
            }
        }
    }

    private suspend fun download(text: String): ByteArray? = withContext(Dispatchers.IO) {
        val encoded = URLEncoder.encode(text, "UTF-8")
        val url = URL("https://translate.googleapis.com/translate_tts?ie=UTF-8&q=$encoded&tl=vi&client=gtx")
        suspendCancellableCoroutine { continuation ->
            val connection = url.openConnection() as HttpURLConnection
            continuation.invokeOnCancellation {
                Dispatchers.IO.dispatch(EmptyCoroutineContext, Runnable { runCatching { connection.disconnect() } })
            }
            try {
                connection.connectTimeout = 5000
                connection.readTimeout = 7000
                connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 15) Chrome/126.0.0.0 Mobile Safari/537.36")
                val audio = if (continuation.isActive && connection.responseCode in 200..299) {
                    connection.inputStream.use { it.readBytes() }
                } else null
                continuation.resume(audio)
            } catch (_: java.io.IOException) {
                continuation.resume(null)
            } finally {
                connection.disconnect()
            }
        }
    }

    private suspend fun play(audio: ByteArray): Boolean {
        val done = CompletableDeferred<Boolean>()
        val player = MediaPlayer()
        try {
            player.setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            player.setOnErrorListener { _, _, _ ->
                done.complete(false)
                true
            }
            player.setOnCompletionListener { done.complete(true) }
            player.setOnPreparedListener {
                try { it.start() } catch (_: IllegalStateException) { done.complete(false) }
            }
            player.setDataSource(object : MediaDataSource() {
                override fun getSize(): Long = audio.size.toLong()
                override fun close() = Unit
                override fun readAt(position: Long, buffer: ByteArray, offset: Int, size: Int): Int {
                    if (size == 0) return 0
                    if (position !in 0L until audio.size.toLong()) return -1
                    val start = position.toInt()
                    val count = minOf(size, audio.size - start)
                    audio.copyInto(buffer, offset, start, start + count)
                    return count
                }
            })
            player.prepareAsync()
            return withTimeoutOrNull(45_000L) { done.await() } == true
        } catch (_: java.io.IOException) {
            return false
        } catch (_: IllegalStateException) {
            kotlinx.coroutines.currentCoroutineContext().ensureActive()
            return false
        } finally {
            player.setOnPreparedListener(null)
            player.setOnCompletionListener(null)
            player.setOnErrorListener(null)
            player.release()
        }
    }

    private suspend fun speakWithSystemTts(text: String, id: String) {
        if (systemTts == null) {
            val initialized = CompletableDeferred<Int>()
            val engine = TextToSpeech(context) { initialized.complete(it) }
            systemTts = engine
            systemTtsReady = withTimeoutOrNull(5_000L) { initialized.await() } == TextToSpeech.SUCCESS &&
                engine.setLanguage(Locale.forLanguageTag("vi-VN")) >= TextToSpeech.LANG_AVAILABLE
        }
        val engine = systemTts ?: return
        if (!systemTtsReady) return
        val done = CompletableDeferred<Unit>()
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = Unit
            override fun onDone(utteranceId: String?) { if (utteranceId == id) done.complete(Unit) }
            @Deprecated("Deprecated by Android")
            override fun onError(utteranceId: String?) = onDone(utteranceId)
        })
        if (engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, id) == TextToSpeech.SUCCESS) {
            withTimeoutOrNull(45_000L) { done.await() }
        }
    }
}
