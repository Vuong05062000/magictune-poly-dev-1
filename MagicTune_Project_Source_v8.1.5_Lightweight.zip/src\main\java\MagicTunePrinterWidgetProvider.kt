package com.example.core.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.example.MainActivity
import com.example.R

class MagicTunePrinterWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (id in appWidgetIds) {
            updateWidget(context, appWidgetManager, id)
        }
    }

    companion object {
        fun updateWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {
            try {
                val views = RemoteViews(context.packageName, R.layout.widget_printer_quick)
                val openPrinterIntent = Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    putExtra("TARGET_TAB", "PRINTER")
                }
                val openPi = PendingIntent.getActivity(
                    context,
                    appWidgetId + 6100,
                    openPrinterIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_printer_container, openPi)
                views.setOnClickPendingIntent(R.id.widget_printer_open_tab, openPi)

                val pickIntent = Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    putExtra("TARGET_TAB", "PRINTER")
                    putExtra("ACTION_PICK_FILE", true)
                }
                val pickPi = PendingIntent.getActivity(
                    context,
                    appWidgetId + 6200,
                    pickIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_printer_pick_file, pickPi)
                appWidgetManager.updateAppWidget(appWidgetId, views)
            } catch (_: Throwable) {}
        }
    }
}
