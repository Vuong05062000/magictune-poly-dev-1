package com.example.core.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.view.View
import android.widget.RemoteViews
import com.example.MainActivity
import com.example.R
import java.util.Calendar
import java.util.Locale

class MagicTunePerpetualCalendarWidgetProvider : AppWidgetProvider() {

    companion object {
        const val ACTION_PC_PREV_MONTH = "com.example.core.widget.ACTION_PC_PREV_MONTH"
        const val ACTION_PC_NEXT_MONTH = "com.example.core.widget.ACTION_PC_NEXT_MONTH"
        const val ACTION_PC_RESET_TODAY = "com.example.core.widget.ACTION_PC_RESET_TODAY"
        const val ACTION_PC_SELECT_DAY = "com.example.core.widget.ACTION_PC_SELECT_DAY"

        private const val EXTRA_SEL_YEAR = "extra_sel_year"
        private const val EXTRA_SEL_MONTH = "extra_sel_month"
        private const val EXTRA_SEL_DAY = "extra_sel_day"

        private const val PREFS_NAME = "magictune_perpetual_calendar"
        private const val KEY_VIEW_YEAR = "view_year"
        private const val KEY_VIEW_MONTH = "view_month"
        private const val KEY_SEL_YEAR = "sel_year"
        private const val KEY_SEL_MONTH = "sel_month"
        private const val KEY_SEL_DAY = "sel_day"

        private val CELL_IDS = intArrayOf(
            R.id.pc_cell_00, R.id.pc_cell_01, R.id.pc_cell_02, R.id.pc_cell_03, R.id.pc_cell_04, R.id.pc_cell_05, R.id.pc_cell_06,
            R.id.pc_cell_07, R.id.pc_cell_08, R.id.pc_cell_09, R.id.pc_cell_10, R.id.pc_cell_11, R.id.pc_cell_12, R.id.pc_cell_13,
            R.id.pc_cell_14, R.id.pc_cell_15, R.id.pc_cell_16, R.id.pc_cell_17, R.id.pc_cell_18, R.id.pc_cell_19, R.id.pc_cell_20,
            R.id.pc_cell_21, R.id.pc_cell_22, R.id.pc_cell_23, R.id.pc_cell_24, R.id.pc_cell_25, R.id.pc_cell_26, R.id.pc_cell_27,
            R.id.pc_cell_28, R.id.pc_cell_29, R.id.pc_cell_30, R.id.pc_cell_31, R.id.pc_cell_32, R.id.pc_cell_33, R.id.pc_cell_34,
            R.id.pc_cell_35, R.id.pc_cell_36, R.id.pc_cell_37, R.id.pc_cell_38, R.id.pc_cell_39, R.id.pc_cell_40, R.id.pc_cell_41
        )

        private val SOLAR_IDS = intArrayOf(
            R.id.pc_sol_00, R.id.pc_sol_01, R.id.pc_sol_02, R.id.pc_sol_03, R.id.pc_sol_04, R.id.pc_sol_05, R.id.pc_sol_06,
            R.id.pc_sol_07, R.id.pc_sol_08, R.id.pc_sol_09, R.id.pc_sol_10, R.id.pc_sol_11, R.id.pc_sol_12, R.id.pc_sol_13,
            R.id.pc_sol_14, R.id.pc_sol_15, R.id.pc_sol_16, R.id.pc_sol_17, R.id.pc_sol_18, R.id.pc_sol_19, R.id.pc_sol_20,
            R.id.pc_sol_21, R.id.pc_sol_22, R.id.pc_sol_23, R.id.pc_sol_24, R.id.pc_sol_25, R.id.pc_sol_26, R.id.pc_sol_27,
            R.id.pc_sol_28, R.id.pc_sol_29, R.id.pc_sol_30, R.id.pc_sol_31, R.id.pc_sol_32, R.id.pc_sol_33, R.id.pc_sol_34,
            R.id.pc_sol_35, R.id.pc_sol_36, R.id.pc_sol_37, R.id.pc_sol_38, R.id.pc_sol_39, R.id.pc_sol_40, R.id.pc_sol_41
        )

        private val LUNAR_IDS = intArrayOf(
            R.id.pc_lun_00, R.id.pc_lun_01, R.id.pc_lun_02, R.id.pc_lun_03, R.id.pc_lun_04, R.id.pc_lun_05, R.id.pc_lun_06,
            R.id.pc_lun_07, R.id.pc_lun_08, R.id.pc_lun_09, R.id.pc_lun_10, R.id.pc_lun_11, R.id.pc_lun_12, R.id.pc_lun_13,
            R.id.pc_lun_14, R.id.pc_lun_15, R.id.pc_lun_16, R.id.pc_lun_17, R.id.pc_lun_18, R.id.pc_lun_19, R.id.pc_lun_20,
            R.id.pc_lun_21, R.id.pc_lun_22, R.id.pc_lun_23, R.id.pc_lun_24, R.id.pc_lun_25, R.id.pc_lun_26, R.id.pc_lun_27,
            R.id.pc_lun_28, R.id.pc_lun_29, R.id.pc_lun_30, R.id.pc_lun_31, R.id.pc_lun_32, R.id.pc_lun_33, R.id.pc_lun_34,
            R.id.pc_lun_35, R.id.pc_lun_36, R.id.pc_lun_37, R.id.pc_lun_38, R.id.pc_lun_39, R.id.pc_lun_40, R.id.pc_lun_41
        )

        fun notifyAllWidgets(context: Context) {
            try {
                val awm = AppWidgetManager.getInstance(context)
                val ids = awm.getAppWidgetIds(ComponentName(context, MagicTunePerpetualCalendarWidgetProvider::class.java))
                for (id in ids) {
                    updateWidget(context, awm, id)
                }
            } catch (_: Throwable) {}
        }

        fun updateWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {
            try {
                val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                val todayCal = Calendar.getInstance()
                val curYear = todayCal.get(Calendar.YEAR)
                val curMonth = todayCal.get(Calendar.MONTH) + 1
                val curDay = todayCal.get(Calendar.DAY_OF_MONTH)

                val viewYear = prefs.getInt(KEY_VIEW_YEAR, curYear).coerceIn(1900, 2100)
                val viewMonth = prefs.getInt(KEY_VIEW_MONTH, curMonth).coerceIn(1, 12)
                val isViewingCurrentMonth = (viewYear == curYear && viewMonth == curMonth)

                val selYear = prefs.getInt(KEY_SEL_YEAR, if (isViewingCurrentMonth) curDay.let { curYear } else viewYear)
                val selMonth = prefs.getInt(KEY_SEL_MONTH, if (isViewingCurrentMonth) curMonth else viewMonth)
                val selDay = prefs.getInt(KEY_SEL_DAY, if (isViewingCurrentMonth) curDay else 1)

                val views = RemoteViews(context.packageName, R.layout.widget_perpetual_calendar)

                val grid = VietnameseLunarCalendar.buildMonthGrid(viewYear, viewMonth)

                // Tìm tên các tháng âm xuất hiện trong tháng dương lịch hiện tại
                val currentMonthCells = grid.filter { it.isCurrentMonth }
                val firstLunar = currentMonthCells.firstOrNull()?.lunar
                val lastLunar = currentMonthCells.lastOrNull()?.lunar
                val lunarBanner = if (firstLunar != null && lastLunar != null) {
                    val monthPart = if (firstLunar.month == lastLunar.month && firstLunar.isLeapMonth == lastLunar.isLeapMonth) {
                        firstLunar.lunarMonthName
                    } else {
                        "${firstLunar.lunarMonthName} - ${lastLunar.lunarMonthName.removePrefix("Tháng ")}"
                    }
                    "🌙 $monthPart • Năm ${lastLunar.yearCanChi}"
                } else {
                    "🌙 Lịch Vạn Niên Âm Dương"
                }

                views.setTextViewText(R.id.widget_pc_month_year, "📅 THÁNG $viewMonth • $viewYear")
                views.setTextViewText(R.id.widget_pc_lunar_month_banner, lunarBanner)
                views.setViewVisibility(R.id.widget_pc_btn_today, if (isViewingCurrentMonth && selDay == curDay) View.GONE else View.VISIBLE)

                var activeDetailCell: VietnameseLunarCalendar.CalendarDayCell? = null

                for (i in 0 until 42) {
                    val cell = grid[i]
                    val cellId = CELL_IDS[i]
                    val solId = SOLAR_IDS[i]
                    val lunId = LUNAR_IDS[i]

                    val isSelected = cell.solarYear == selYear &&
                        cell.solarMonth == selMonth &&
                        cell.solarDay == selDay

                    if (isSelected) {
                        activeDetailCell = cell
                    }

                    views.setTextViewText(solId, cell.solarDay.toString())
                    views.setTextViewText(lunId, cell.lunar.shortDisplay)

                    // Nền ô: Ưu tiên Hôm nay > Đang chọn > Mùng 1 / Rằm / Ngày Lễ > Trống
                    val bgRes = when {
                        cell.isToday -> R.drawable.widget_calendar_today_cell_bg
                        isSelected -> R.drawable.widget_calendar_selected_cell_bg
                        cell.isCurrentMonth && cell.isSpecialLunar -> R.drawable.widget_calendar_special_cell_bg
                        else -> 0
                    }
                    views.setInt(cellId, "setBackgroundResource", bgRes)

                    // Màu chữ ngày dương lịch
                    val solarColor = when {
                        cell.isToday -> Color.WHITE
                        !cell.isCurrentMonth -> Color.parseColor("#475569")
                        cell.dayOfWeekCol == 6 -> Color.parseColor("#FB7185") // Chủ nhật đỏ san hô
                        cell.dayOfWeekCol == 5 -> Color.parseColor("#FBBF24") // Thứ 7 vàng hổ phách
                        else -> Color.parseColor("#F8FAFC")
                    }
                    views.setTextColor(solId, solarColor)

                    // Màu chữ ngày âm lịch
                    val lunarColor = when {
                        cell.isToday -> Color.parseColor("#38BDF8")
                        !cell.isCurrentMonth -> Color.parseColor("#334155")
                        cell.lunar.day == 1 -> Color.parseColor("#FB7185") // Mùng 1 âm nổi bật đỏ/vàng
                        cell.lunar.day == 15 || !cell.holidayName.isNullOrBlank() -> Color.parseColor("#FBBF24")
                        else -> Color.parseColor("#94A3B8")
                    }
                    views.setTextColor(lunId, lunarColor)

                    // Cho phép chạm trực tiếp từng ngày trong tháng để xem chi tiết Can Chi & Ngày Lễ
                    val selectIntent = Intent(context, MagicTunePerpetualCalendarWidgetProvider::class.java).apply {
                        action = ACTION_PC_SELECT_DAY
                        putExtra(EXTRA_SEL_YEAR, cell.solarYear)
                        putExtra(EXTRA_SEL_MONTH, cell.solarMonth)
                        putExtra(EXTRA_SEL_DAY, cell.solarDay)
                    }
                    val selectPi = PendingIntent.getBroadcast(
                        context,
                        4100 + i,
                        selectIntent,
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                    )
                    views.setOnClickPendingIntent(cellId, selectPi)
                }

                val detailCell = activeDetailCell
                    ?: grid.firstOrNull { it.isToday }
                    ?: grid.firstOrNull { it.isCurrentMonth && it.solarDay == 1 }
                    ?: grid[0]

                val lunarLeapStr = if (detailCell.lunar.isLeapMonth) " Nhuận" else ""
                val prefixTag = if (detailCell.isToday) "Hôm nay" else "Đang xem"
                val line1Raw = String.format(
                    Locale.US,
                    "📅 %s %02d/%02d/%d • 🌙 %02d/%02d%s ÂL (%s)",
                    prefixTag,
                    detailCell.solarDay,
                    detailCell.solarMonth,
                    detailCell.solarYear,
                    detailCell.lunar.day,
                    detailCell.lunar.month,
                    lunarLeapStr,
                    detailCell.lunar.yearCanChi
                )
                val line2Raw = if (!detailCell.holidayName.isNullOrBlank()) {
                    "🎉 ${detailCell.holidayName} • Ngày ${detailCell.lunar.dayCanChi} • Tháng ${detailCell.lunar.monthCanChi}"
                } else {
                    "✨ Ngày ${detailCell.lunar.dayCanChi} • Tháng ${detailCell.lunar.monthCanChi}"
                }
                views.setTextViewText(R.id.widget_pc_detail_line1, line1Raw)
                views.setTextViewText(R.id.widget_pc_detail_line2, line2Raw)

                // Nút lùi / tiến tháng / Hôm nay
                val prevPi = PendingIntent.getBroadcast(
                    context,
                    4001,
                    Intent(context, MagicTunePerpetualCalendarWidgetProvider::class.java).apply { action = ACTION_PC_PREV_MONTH },
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_pc_btn_prev, prevPi)

                val nextPi = PendingIntent.getBroadcast(
                    context,
                    4002,
                    Intent(context, MagicTunePerpetualCalendarWidgetProvider::class.java).apply { action = ACTION_PC_NEXT_MONTH },
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_pc_btn_next, nextPi)

                val todayPi = PendingIntent.getBroadcast(
                    context,
                    4003,
                    Intent(context, MagicTunePerpetualCalendarWidgetProvider::class.java).apply { action = ACTION_PC_RESET_TODAY },
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_pc_btn_today, todayPi)

                // Bấm vào thanh tiêu đề hoặc nút "📖 Chi tiết" -> Mở Quyển Lịch Vạn Niên đầy đủ trong MagicTune
                val openAppIntent = Intent(context, MainActivity::class.java).apply {
                    `package` = context.packageName
                    action = "com.example.ACTION_OPEN_PERPETUAL_CALENDAR"
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    putExtra("TARGET_TAB", "PERPETUAL_CALENDAR")
                }
                val openAppPi = PendingIntent.getActivity(
                    context,
                    4050 + appWidgetId,
                    openAppIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_pc_header_title_area, openAppPi)
                views.setOnClickPendingIntent(R.id.widget_pc_btn_open_app, openAppPi)
                views.setOnClickPendingIntent(R.id.widget_pc_footer_root, openAppPi)

                appWidgetManager.updateAppWidget(appWidgetId, views)
            } catch (_: Throwable) {}
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) {
            updateWidget(context, appWidgetManager, id)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val action = intent.action ?: return
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val todayCal = Calendar.getInstance()
        val curYear = todayCal.get(Calendar.YEAR)
        val curMonth = todayCal.get(Calendar.MONTH) + 1
        val curDay = todayCal.get(Calendar.DAY_OF_MONTH)

        when (action) {
            ACTION_PC_PREV_MONTH -> {
                val y = prefs.getInt(KEY_VIEW_YEAR, curYear)
                val m = prefs.getInt(KEY_VIEW_MONTH, curMonth)
                val c = Calendar.getInstance().apply {
                    set(y, m - 1, 1, 12, 0, 0)
                    add(Calendar.MONTH, -1)
                }
                val newY = c.get(Calendar.YEAR)
                val newM = c.get(Calendar.MONTH) + 1
                val newD = if (newY == curYear && newM == curMonth) curDay else 1
                prefs.edit()
                    .putInt(KEY_VIEW_YEAR, newY)
                    .putInt(KEY_VIEW_MONTH, newM)
                    .putInt(KEY_SEL_YEAR, newY)
                    .putInt(KEY_SEL_MONTH, newM)
                    .putInt(KEY_SEL_DAY, newD)
                    .apply()
                notifyAllWidgets(context)
            }
            ACTION_PC_NEXT_MONTH -> {
                val y = prefs.getInt(KEY_VIEW_YEAR, curYear)
                val m = prefs.getInt(KEY_VIEW_MONTH, curMonth)
                val c = Calendar.getInstance().apply {
                    set(y, m - 1, 1, 12, 0, 0)
                    add(Calendar.MONTH, 1)
                }
                val newY = c.get(Calendar.YEAR)
                val newM = c.get(Calendar.MONTH) + 1
                val newD = if (newY == curYear && newM == curMonth) curDay else 1
                prefs.edit()
                    .putInt(KEY_VIEW_YEAR, newY)
                    .putInt(KEY_VIEW_MONTH, newM)
                    .putInt(KEY_SEL_YEAR, newY)
                    .putInt(KEY_SEL_MONTH, newM)
                    .putInt(KEY_SEL_DAY, newD)
                    .apply()
                notifyAllWidgets(context)
            }
            ACTION_PC_RESET_TODAY,
            Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED -> {
                prefs.edit()
                    .putInt(KEY_VIEW_YEAR, curYear)
                    .putInt(KEY_VIEW_MONTH, curMonth)
                    .putInt(KEY_SEL_YEAR, curYear)
                    .putInt(KEY_SEL_MONTH, curMonth)
                    .putInt(KEY_SEL_DAY, curDay)
                    .apply()
                notifyAllWidgets(context)
            }
            ACTION_PC_SELECT_DAY -> {
                val y = intent.getIntExtra(EXTRA_SEL_YEAR, curYear)
                val m = intent.getIntExtra(EXTRA_SEL_MONTH, curMonth)
                val d = intent.getIntExtra(EXTRA_SEL_DAY, curDay)
                prefs.edit()
                    .putInt(KEY_VIEW_YEAR, y)
                    .putInt(KEY_VIEW_MONTH, m)
                    .putInt(KEY_SEL_YEAR, y)
                    .putInt(KEY_SEL_MONTH, m)
                    .putInt(KEY_SEL_DAY, d)
                    .apply()
                notifyAllWidgets(context)
            }
        }
    }
}
