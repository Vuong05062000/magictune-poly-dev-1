package com.example.core.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews
import android.widget.Toast
import com.example.MainActivity
import com.example.R
import com.example.core.ai.AiPowerAutopilotManager
import com.example.core.service.MagicTuneKeepAliveService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Widget Pin 3×2 Siêu Nhẹ & Tiết Kiệm Pin (Tối ưu ngang bản 2×2):
 * - Hoàn toàn thụ động: KHÔNG hồi sinh dịch vụ nền, KHÔNG chạy Chronometer 1Hz, KHÔNG gọi ADB dumpsys hay tự động hạ nhiệt ngầm trong lúc vẽ widget.
 * - Chỉ đọc dữ liệu nhẹ từ sticky Intent pin + bộ nhớ đệm tốc độ xả %/h, giữ lại đúng các thông số cốt lõi & 2 nút Làm mới / Hạ nhiệt 1 chạm.
 */
class MagicTuneBatteryWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        val appCtx = context.applicationContext ?: context
        val idsCopy = appWidgetIds.copyOf()
        val pendingResult = goAsync()
        val finishedFlag = java.util.concurrent.atomic.AtomicBoolean(false)
        fun finishSafely() {
            if (finishedFlag.compareAndSet(false, true)) {
                try { pendingResult.finish() } catch (_: Throwable) {}
            }
        }
        CoroutineScope(Dispatchers.IO).launch {
            try {
                for (appWidgetId in idsCopy) {
                    updateWidget(appCtx, appWidgetManager, appWidgetId)
                }
            } catch (_: Throwable) {
            } finally {
                finishSafely()
            }
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val action = intent.action ?: return
        if (action == ACTION_BATTERY_WIDGET_NOOP) return
        val appCtx = context.applicationContext ?: context
        val now = SystemClock.elapsedRealtime()

        if (action == ACTION_WIDGET_COOL_BOOST) {
            val pendingResult = goAsync()
            val finishedFlag = java.util.concurrent.atomic.AtomicBoolean(false)
            fun finishBroadcastSafely() {
                if (finishedFlag.compareAndSet(false, true)) {
                    try { pendingResult.finish() } catch (_: Throwable) {}
                }
            }
            // Watchdog bảo vệ tuyệt đối chống ANR nếu tác vụ chạy ngầm mất quá nhiều thời gian
            CoroutineScope(Dispatchers.IO).launch {
                kotlinx.coroutines.delay(8_500L)
                finishBroadcastSafely()
            }
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val awm = AppWidgetManager.getInstance(appCtx)
                    val ids = awm.getAppWidgetIds(ComponentName(appCtx, MagicTuneBatteryWidgetProvider::class.java))
                    for (id in ids) {
                        updateWidget(appCtx, awm, id, "⚡ Đang bật Tiết kiệm pin Android...")
                    }
                } catch (_: Throwable) {}
            }
            performCoolingAndOptimization(
                context = appCtx,
                isManualTrigger = true,
                onReportReady = { report ->
                    CoroutineScope(Dispatchers.Main).launch {
                        try {
                            Toast.makeText(appCtx, report.summaryText, Toast.LENGTH_LONG).show()
                        } catch (_: Throwable) {}
                    }
                    CoroutineScope(Dispatchers.IO).launch {
                        val compactBanner = if (report.powerSaverEnabled) {
                            "⚡ Tiết kiệm pin Android đang bật"
                        } else {
                            "ADB chưa áp dụng được chế độ tiết kiệm pin"
                        }
                        try {
                            val awmNow = AppWidgetManager.getInstance(appCtx)
                            val idsNow = awmNow.getAppWidgetIds(ComponentName(appCtx, MagicTuneBatteryWidgetProvider::class.java))
                            for (id in idsNow) {
                                updateWidget(appCtx, awmNow, id, compactBanner)
                            }
                            MagicTuneSimpleBatteryWidgetProvider.notifyAllWidgets(appCtx, compactBanner)
                        } catch (_: Throwable) {}
                        // Finish immediately; no delayed refresh or periodic wakeup is needed.
                        finishBroadcastSafely()
                    }
                },
                onFinished = {
                    finishBroadcastSafely()
                }
            )
            return
        }

        val shouldRefreshWidget = action == ACTION_WIDGET_FORCE_REFRESH ||
            action == Intent.ACTION_POWER_CONNECTED ||
            action == Intent.ACTION_POWER_DISCONNECTED ||
            action == Intent.ACTION_BATTERY_LOW ||
            action == Intent.ACTION_BATTERY_OKAY

        if (!shouldRefreshWidget) {
            if (now - BatteryInfoReader.forceDisconnectedTimeMs > 2500L &&
                now - BatteryInfoReader.forceConnectedTimeMs > 2500L
            ) {
                BatteryInfoReader.forceConnected = false
                BatteryInfoReader.forceDisconnected = false
            }
            return
        }

        val isManualRefreshTap = action == ACTION_WIDGET_FORCE_REFRESH

        val pendingResult = goAsync()
        val finishedFlag = java.util.concurrent.atomic.AtomicBoolean(false)
        fun finishSafely() {
            if (finishedFlag.compareAndSet(false, true)) {
                try { pendingResult.finish() } catch (_: Throwable) {}
            }
        }
        // Watchdog bảo vệ chống ANR BroadcastReceiver
        CoroutineScope(Dispatchers.IO).launch {
            kotlinx.coroutines.delay(8_500L)
            finishSafely()
        }

        CoroutineScope(Dispatchers.IO).launch {
            try {
                when (action) {
                    Intent.ACTION_POWER_DISCONNECTED -> BatteryInfoReader.onPowerDisconnected(appCtx)
                    Intent.ACTION_POWER_CONNECTED -> BatteryInfoReader.onPowerConnected(appCtx)
                    else -> {
                        if (now - BatteryInfoReader.forceDisconnectedTimeMs > 2500L &&
                            now - BatteryInfoReader.forceConnectedTimeMs > 2500L
                        ) {
                            BatteryInfoReader.forceConnected = false
                            BatteryInfoReader.forceDisconnected = false
                        }
                    }
                }
                // Đóng dấu mốc Fuel Gauge µAh tức thì (<0.2ms) để đo tốc độ xả %/h chính xác ngay lập tức
                AiPowerAutopilotManager.recordLiveFuelGaugeCheckpoint(
                    context = appCtx,
                    force = isManualRefreshTap || action == Intent.ACTION_POWER_CONNECTED || action == Intent.ACTION_POWER_DISCONNECTED
                )
                val awm = AppWidgetManager.getInstance(appCtx)
                val ids = awm.getAppWidgetIds(ComponentName(appCtx, MagicTuneBatteryWidgetProvider::class.java))
                for (id in ids) {
                    updateWidget(appCtx, awm, id)
                }
                if (isManualRefreshTap) {
                    MagicTuneSimpleBatteryWidgetProvider.notifyAllWidgets(appCtx)
                    val hhmm = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
                    CoroutineScope(Dispatchers.Main).launch {
                        try {
                            Toast.makeText(appCtx, "✓ Đã đo lại pin µAh lúc $hhmm", Toast.LENGTH_SHORT).show()
                        } catch (_: Throwable) {}
                    }
                }
            } catch (_: Throwable) {
            } finally {
                finishSafely()
            }
        }
    }

    companion object {
        const val ACTION_WIDGET_FORCE_REFRESH = "com.example.core.widget.ACTION_WIDGET_FORCE_REFRESH"
        const val ACTION_WIDGET_COOL_BOOST = "com.example.core.widget.ACTION_WIDGET_COOL_BOOST"
        const val ACTION_BATTERY_WIDGET_NOOP = "com.example.core.widget.ACTION_BATTERY_WIDGET_NOOP"
        const val AUTO_COOL_THRESHOLD_CELSIUS = 38.5

        fun notifyAllWidgetsFast(context: Context, customBannerOverride: String? = null) {
            try {
                val appCtx = context.applicationContext ?: context
                val pm = appCtx.getSystemService(Context.POWER_SERVICE) as? android.os.PowerManager
                if (pm != null && !pm.isInteractive) return
                val awm = AppWidgetManager.getInstance(appCtx)
                val ids = awm.getAppWidgetIds(ComponentName(appCtx, MagicTuneBatteryWidgetProvider::class.java))
                for (id in ids) {
                    updateWidget(appCtx, awm, id, customBannerOverride)
                }
            } catch (_: Throwable) {}
        }

        data class CoolingExecutionReport(
            val powerSaverEnabled: Boolean,
            val adbApplied: Boolean,
            val summaryText: String
        )

        private val isCoolingCurrentlyRunning = java.util.concurrent.atomic.AtomicBoolean(false)

        /**
         * Kiểm tra xem MagicLive hoặc Dịch Cuộn (hay Khoanh màn hình hỏi MagicLive) có đang hoạt động hay không.
         * Khi một trong các tính năng này đang chạy, quá trình hạ nhiệt tự động sẽ bảo vệ tuyệt đối 100%
         * (không ngắt Trợ năng, không ngắt Micro/TTS, không đóng ứng dụng đang dịch trên màn hình và không chạy lệnh I/O nặng gây khựng).
         */
        fun isMagicLiveOrScrollTranslateRunning(): Boolean {
            return MagicLiveFloatingOverlay.isShowing ||
                MagicLiveFloatingOverlay.isVoiceOrSpeechActive() ||
                GoogleLiveTranslateOverlay.isRunning ||
                com.example.core.service.NoAccessibilityScreenEngine.isLiveScrollTranslateActive ||
                CircleToSearchOverlayActivity.isOverlayActive ||
                CircleToSearchWindowOverlay.isShowing
        }

        /** User-triggered power-saving action. No process sweep or repeated thermal polling. */
        suspend fun runSuperCoolingEngine(
            context: Context,
            isManualTrigger: Boolean = false
        ): CoolingExecutionReport {
            val appCtx = context.applicationContext ?: context
            val result = com.example.core.perf.SafeThermalRelief.enable(appCtx)
            val timeStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            val summary = "⚡ Giảm tải an toàn ($timeStr): ${result.message}"
            BatteryInfoReader.saveCoolingTelemetryReport(appCtx, summary)
            return CoolingExecutionReport(
                powerSaverEnabled = result.enabled,
                adbApplied = result.success,
                summaryText = summary
            )
        }

        /**
         * Thực thi Hạ nhiệt & Tối ưu thông minh đa tầng (bảo vệ tuyệt đối 100% MagicLive, Dịch Cuộn & Zalo/Banking).
         */
        fun performCoolingAndOptimization(
            context: Context,
            isManualTrigger: Boolean = false,
            onReportReady: ((CoolingExecutionReport) -> Unit)? = null,
            onFinished: (() -> Unit)? = null
        ) {
            if (!isCoolingCurrentlyRunning.compareAndSet(false, true)) {
                onFinished?.invoke()
                return
            }
            val appCtx = context.applicationContext ?: context
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val report = kotlinx.coroutines.withTimeoutOrNull(4_500L) {
                        runSuperCoolingEngine(appCtx, isManualTrigger = isManualTrigger)
                    }
                    if (report != null) {
                        onReportReady?.invoke(report)
                    }
                } catch (_: Throwable) {
                } finally {
                    isCoolingCurrentlyRunning.set(false)
                    onFinished?.invoke()
                }
            }
        }

        fun updateWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int,
            customBannerOverride: String? = null
        ) {
            try {
                val batteryIntent: Intent? = try {
                    context.applicationContext.registerReceiver(
                        null,
                        IntentFilter(Intent.ACTION_BATTERY_CHANGED)
                    )
                } catch (_: Throwable) {
                    null
                }

                // Đọc siêu nhẹ (0 quét sysfs nhiệt độ CPU, 0 đọc chu kỳ sạc, 0 đọc dòng xả khi không sạc)
                val data = BatteryInfoReader.read(context, batteryIntent, lightweight = true)
                val isCharging = data.isCharging
                val views = RemoteViews(context.packageName, R.layout.widget_battery_live)

                // 1. Trạng thái gọn (chỉ 1 icon phích điện 🔌 khi đang sạc) + Nhiệt độ pin
                val statusText = if (isCharging) {
                    when {
                        data.batteryPct >= 100 && !data.isFullySaturated -> "⚡ NGÂM 100%"
                        data.batteryPct >= 100 -> "🔌 NO 100%"
                        data.currentWatts >= 35.0 -> "🔌 SIÊU NHANH"
                        data.currentWatts >= 18.0 -> "🔌 SẠC NHANH"
                        else -> "🔌 ĐANG SẠC"
                    }
                } else {
                    if (data.batteryPct <= 20) "⚠️ PIN YẾU" else "🔋 ĐANG DÙNG"
                }
                val statusColor = when {
                    isCharging && data.batteryPct >= 100 && data.isFullySaturated -> Color.parseColor("#34D399")
                    isCharging && data.batteryPct >= 100 && !data.isFullySaturated -> Color.parseColor("#38BDF8")
                    isCharging -> Color.parseColor("#FBBF24")
                    data.batteryPct <= 20 -> Color.parseColor("#FB7185")
                    data.batteryPct <= 40 -> Color.parseColor("#FBBF24")
                    else -> Color.parseColor("#34D399")
                }
                views.setTextViewText(R.id.widget_status, statusText)
                views.setTextColor(R.id.widget_status, statusColor)

                val tempColor = when {
                    !data.isBatteryTemperatureAvailable -> Color.parseColor("#94A3B8")
                    data.tempCelsius >= 41.0 -> Color.parseColor("#FB7185")
                    data.tempCelsius >= 37.5 -> Color.parseColor("#FBBF24")
                    else -> Color.parseColor("#7DD3FC")
                }
                views.setTextViewText(
                    R.id.widget_temp,
                    if (data.isBatteryTemperatureAvailable) {
                        String.format(Locale.US, "🌡️ %.1f°C", data.tempCelsius)
                    } else {
                        "🌡️ --°C"
                    }
                )
                views.setTextColor(R.id.widget_temp, tempColor)

                // 2. Phần trăm Pin lớn + Thanh tiến trình màu sắc
                views.setTextViewText(R.id.widget_battery_pct, "${data.batteryPct}%")
                val pctColor = when {
                    isCharging -> Color.parseColor("#34D399")
                    data.batteryPct <= 20 -> Color.parseColor("#FB7185")
                    data.batteryPct <= 35 -> Color.parseColor("#FBBF24")
                    data.batteryPct <= 60 -> Color.parseColor("#38BDF8")
                    else -> Color.parseColor("#34D399")
                }
                views.setTextColor(R.id.widget_battery_pct, pctColor)
                views.setProgressBar(R.id.widget_battery_progress, 100, data.batteryPct.coerceIn(0, 100), false)

                // 3. Hai dòng thông tin cốt lõi bên cạnh % Pin (không lặp icon sạc thứ 2, không Chronometer 1Hz)
                var resolvedEstOnHours = data.estimatedScreenOnHours
                var resolvedEstOnMins = data.estimatedScreenOnMins
                var resolvedEstStandbyHours = data.estimatedStandbyHours

                if (isCharging) {
                    if (data.batteryPct >= 100) {
                        if (!data.isFullySaturated) {
                            val remText = if (data.saturationRemainingMinutes > 0) {
                                String.format(Locale.US, "Nạp bù ion ~%dp (%.1fW)", data.saturationRemainingMinutes, data.currentWatts)
                            } else {
                                String.format(Locale.US, "Nạp bù ion (%.1fW)", data.currentWatts)
                            }
                            views.setTextViewText(R.id.widget_charge_watt, remText)
                            views.setTextColor(R.id.widget_charge_watt, Color.parseColor("#38BDF8"))
                            views.setTextViewText(R.id.widget_charge_speed_type, "Đang nạp tiếp đến khi dòng về ≤ 1W")
                            views.setTextColor(R.id.widget_charge_speed_type, Color.parseColor("#BAE6FD"))
                        } else {
                            views.setTextViewText(
                                R.id.widget_charge_watt,
                                String.format(Locale.US, "Đã ngắt dòng an toàn (%.1fW)", data.currentWatts)
                            )
                            views.setTextColor(R.id.widget_charge_watt, Color.parseColor("#34D399"))
                            views.setTextViewText(R.id.widget_charge_speed_type, "Đã no 100% thực tế (≤ 1W) • Hãy rút sạc")
                            views.setTextColor(R.id.widget_charge_speed_type, Color.parseColor("#A7F3D0"))
                        }
                    } else {
                        val etaText = if (data.minutesToFull > 0) " • Đầy ~${data.minutesToFull}p" else ""
                        val cleanSpeedLabel = when {
                            data.currentWatts >= 35.0 -> "Siêu nhanh"
                            data.currentWatts >= 18.0 -> "Sạc nhanh"
                            else -> "Sạc thường"
                        }
                        views.setTextViewText(
                            R.id.widget_charge_watt,
                            String.format(Locale.US, "%.1fW%s", data.currentWatts, etaText)
                        )
                        views.setTextColor(R.id.widget_charge_watt, Color.parseColor("#FBBF24"))
                        views.setTextViewText(
                            R.id.widget_charge_speed_type,
                            String.format(Locale.US, "%s • %.2fV", cleanSpeedLabel, data.voltageV)
                        )
                        views.setTextColor(R.id.widget_charge_speed_type, Color.parseColor("#A7F3D0"))
                    }
                } else {
                    val drainAnalytics = try {
                        AiPowerAutopilotManager.getDrainRateAnalytics(
                            context = context,
                            lightweightRead = true,
                            preloadedBattery = data
                        )
                    } catch (_: Throwable) {
                        null
                    }
                    val onRate = drainAnalytics?.screenOnDrainPctPerHour
                    val offRate = drainAnalytics?.screenOffDrainPctPerHour
                    val onPrefix = if (drainAnalytics?.screenOnSource == "Ước tính") "~" else ""
                    val offPrefix = if (drainAnalytics?.screenOffSource == "Ước tính nền") "~" else ""
                    val onRateStr = onRate?.let { String.format(Locale.US, "%s%.1f%%/h", onPrefix, it) } ?: "--%/h"
                    val offRateStr = offRate?.let { String.format(Locale.US, "%s%.1f%%/h", offPrefix, it) } ?: "--%/h"

                    if (data.batteryPct > 0) {
                        val totalMins = AiPowerAutopilotManager.estimateScreenOnMinutes(
                            batteryPct = data.batteryPct,
                            screenOnDrainPctPerHour = onRate,
                            designCapacityMah = data.designCapacityMah
                        )
                        resolvedEstOnHours = totalMins / 60
                        resolvedEstOnMins = totalMins % 60
                    }
                    if (offRate != null && offRate > 0.1 && data.batteryPct > 0) {
                        resolvedEstStandbyHours = (data.batteryPct.toDouble() / maxOf(offRate, 1.1)).toInt().coerceIn(2, 96)
                    }

                    views.setTextViewText(R.id.widget_charge_watt, "☀️ Sáng màn: $onRateStr")
                    views.setTextColor(
                        R.id.widget_charge_watt,
                        Color.parseColor(if (onRate != null && onRate > 13.5) "#FB7185" else "#38BDF8")
                    )
                    views.setTextViewText(R.id.widget_charge_speed_type, "🌙 Tắt màn chờ: $offRateStr")
                    views.setTextColor(
                        R.id.widget_charge_speed_type,
                        Color.parseColor(if (offRate != null && offRate > 2.5) "#FBBF24" else "#34D399")
                    )
                }

                // 4. Dòng ước tính thời gian dùng/chờ đồng bộ với tốc độ xả (hoặc kết quả hạ nhiệt / làm mới tức thì)
                if (!customBannerOverride.isNullOrBlank()) {
                    views.setTextViewText(R.id.widget_estimated_usage, customBannerOverride)
                    views.setTextColor(R.id.widget_estimated_usage, Color.parseColor("#38BDF8"))
                } else {
                    views.setTextViewText(
                        R.id.widget_estimated_usage,
                        "⏱️ Sáng màn ~${resolvedEstOnHours}h ${resolvedEstOnMins}p • Chờ ~${resolvedEstStandbyHours}h"
                    )
                    views.setTextColor(R.id.widget_estimated_usage, Color.parseColor("#CBD5E1"))
                }

                // 5. Chỉ gắn đúng 3 PendingIntent thiết yếu: Header -> Tab 7, Làm mới, Hạ nhiệt
                val openBatteryTabIntent = Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    putExtra("TARGET_TAB", "BG_DRAIN_MONITOR")
                }
                val openPi = PendingIntent.getActivity(
                    context,
                    appWidgetId + 9100,
                    openBatteryTabIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_header, openPi)

                val refreshIntent = Intent(context, MagicTuneBatteryWidgetProvider::class.java).apply {
                    action = ACTION_WIDGET_FORCE_REFRESH
                }
                val refreshPi = PendingIntent.getBroadcast(
                    context,
                    appWidgetId + 7100,
                    refreshIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_btn_refresh, refreshPi)

                val coolIntent = Intent(context, MagicTuneBatteryWidgetProvider::class.java).apply {
                    action = ACTION_WIDGET_COOL_BOOST
                }
                val coolPi = PendingIntent.getBroadcast(
                    context,
                    appWidgetId + 7200,
                    coolIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_btn_optimize, coolPi)

                appWidgetManager.updateAppWidget(appWidgetId, views)
            } catch (_: Throwable) {}
        }
    }
}
