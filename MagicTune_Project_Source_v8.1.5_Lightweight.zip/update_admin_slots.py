import os

path = r"C:\Users\Administrator\.gemini\antigravity\scratch\MagicTune\src\main\java\AdminManagementScreen.kt"
with open(path, "r", encoding="utf-8") as f:
    text = f.read()

start_marker = 'item(key = "tab0_broadcast", contentType = "admin_setting_card") {'
end_marker = 'item(key = "tab0_key_pool", contentType = "admin_setting_card") {'

if start_marker in text and end_marker in text:
    start_idx = text.find(start_marker)
    end_idx = text.find(end_marker)
    text = text[:start_idx].rstrip() + "\n\n                    " + text[end_idx:]
    print("Removed tab0_broadcast card")

replacements = [
    ("[Ô 1.2]", "[Ô 1.1]"),
    ("[Ô 1.3]", "[Ô 1.2]"),
    ("[Ô 1.4]", "[Ô 1.3]"),
    ("[Ô 1.5]", "[Ô 1.4]"),
    ("[Ô 1.6]", "[Ô 1.5]"),
    ("[Ô 1.7]", "[Ô 1.6]"),
    ("[Ô 1.8]", "[Ô 1.7]"),
    ("[Ô 1.9]", "[Ô 1.8]"),
    ("[Ô 1.10]", "[Ô 1.9]"),
    ("// [Ô 1.10]", "// [Ô 1.9]")
]

for old, new in replacements:
    if old in text:
        text = text.replace(old, new)
        print(f"Replaced {old} -> {new}")

with open(path, "w", encoding="utf-8") as f:
    f.write(text)

print("Saved AdminManagementScreen.kt successfully!")
