package com.example.core.service

import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.Context

/**
 * Kept only to cancel jobs scheduled by older versions. MagicTune no longer schedules
 * persistent or immediate-revive jobs; background features must be started by an explicit user action.
 */
class MagicTuneKeepAliveJobService : JobService() {
    override fun onStartJob(params: JobParameters?): Boolean {
        cancelAll(applicationContext)
        return false
    }

    override fun onStopJob(params: JobParameters?): Boolean {
        return false
    }

    companion object {
        const val JOB_ID_PERIODIC_HEALTH = 41001
        const val JOB_ID_IMMEDIATE_REVIVE = 41002

        fun ensureScheduled(context: Context) {
            val appCtx = context.applicationContext ?: context
            cancelAll(appCtx)
        }

        fun scheduleImmediateRevive(context: Context, delayMs: Long = 1200L) {
            val appCtx = context.applicationContext ?: context
            cancelAll(appCtx)
        }

        fun cancelAll(context: Context) {
            try {
                val js = context.applicationContext.getSystemService(Context.JOB_SCHEDULER_SERVICE) as? JobScheduler ?: return
                js.cancel(JOB_ID_PERIODIC_HEALTH)
                js.cancel(JOB_ID_IMMEDIATE_REVIVE)
            } catch (_: Throwable) {}
        }
    }
}
